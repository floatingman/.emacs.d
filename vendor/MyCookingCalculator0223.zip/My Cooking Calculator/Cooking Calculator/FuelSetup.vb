﻿Imports System.IO
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Windows.Forms.Form
Imports System.Data.OleDb
Imports System.Data
Imports System.Math
Imports Microsoft.VisualBasic
Imports System.Collections
Imports System.Text
Public Class FuelSetup
    Public saveJPEGFile As New SaveFileDialog

    Private Sub SaveDetailToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveDetailToolStripMenuItem.Click
        Dim fileExists As Boolean
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\PersonalDetail.rec")
        Try
            If fileExists Then
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\PersonalDetail.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                strline = txtAAFixFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAccountNum.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress1.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress2.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress3.Text
                objStreamWriter.WriteLine(strline)
                strline = txtBranchNum.Text
                objStreamWriter.WriteLine(strline)
                strline = txtCarFuelFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = txtOwnerName.Text
                objStreamWriter.WriteLine(strline)
                strline = txtPostalCode.Text
                objStreamWriter.WriteLine(strline)
                strline = txtServiceRepairCost.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTelephone.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTypeAccount.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTyreCostFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = cmbBankName.Text
                objStreamWriter.WriteLine(strline)
                strline = txtPetrolPrice.text
                objStreamWriter.WriteLine(strline)
                objStreamWriter.Close()
            Else
                My.Computer.FileSystem.WriteAllText(Application.StartupPath & "\PersonalDetail.rec", String.Empty, False)
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\PersonalDetail.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                strline = txtAAFixFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAccountNum.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress1.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress2.Text
                objStreamWriter.WriteLine(strline)
                strline = txtAdress3.Text
                objStreamWriter.WriteLine(strline)
                strline = txtBranchNum.Text
                objStreamWriter.WriteLine(strline)
                strline = txtCarFuelFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = txtOwnerName.Text
                objStreamWriter.WriteLine(strline)
                strline = txtPostalCode.Text
                objStreamWriter.WriteLine(strline)
                strline = txtServiceRepairCost.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTelephone.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTypeAccount.Text
                objStreamWriter.WriteLine(strline)
                strline = txtTyreCostFactor.Text
                objStreamWriter.WriteLine(strline)
                strline = cmbBankName.Text
                objStreamWriter.WriteLine(strline)
                strline = txtPetrolPrice.text
                objStreamWriter.WriteLine(strline)
                objStreamWriter.Close()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FuelSetup_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dispose()
        Me.Close()
    End Sub

    Private Sub FuelSetup_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim PicStr As String = ""
        Me.Location = New Point((Screen.PrimaryScreen.Bounds.Width - Me.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - Me.Height) / 2)
        Dim fileExists, CustomPicture As Boolean
        CustomPicture = False
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\PersonalDetail.rec")
        CustomPicture = My.Computer.FileSystem.FileExists(Application.StartupPath & "\MyLogo.bmp")
        Try
            If fileExists Then
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\PersonalDetail.rec")
                objStreamReader = New StreamReader(Application.StartupPath & "\PersonalDetail.rec")
                strLine = objStreamReader.ReadLine
                txtAAFixFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAccountNum.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress1.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress2.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress3.Text = strLine
                strLine = objStreamReader.ReadLine
                txtBranchNum.Text = strLine
                strLine = objStreamReader.ReadLine
                txtCarFuelFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                txtOwnerName.Text = strLine
                strLine = objStreamReader.ReadLine
                txtPostalCode.Text = strLine
                strLine = objStreamReader.ReadLine
                txtServiceRepairCost.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTelephone.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTypeAccount.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTyreCostFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                cmbBankName.Text = strLine
                strLine = objStreamReader.ReadLine
                txtPetrolPrice.Text = strLine
                objStreamReader.Close()
            Else
                My.Computer.FileSystem.WriteAllText(Application.StartupPath & "\PersonalDetail.rec", String.Empty, False)
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\PersonalDetail.rec")
                objStreamReader = New StreamReader(Application.StartupPath & "\PersonalDetail.rec")
                strLine = objStreamReader.ReadLine
                txtAAFixFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAccountNum.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress1.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress2.Text = strLine
                strLine = objStreamReader.ReadLine
                txtAdress3.Text = strLine
                strLine = objStreamReader.ReadLine
                txtBranchNum.Text = strLine
                strLine = objStreamReader.ReadLine
                txtCarFuelFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                txtOwnerName.Text = strLine
                strLine = objStreamReader.ReadLine
                txtPostalCode.Text = strLine
                strLine = objStreamReader.ReadLine
                txtServiceRepairCost.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTelephone.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTypeAccount.Text = strLine
                strLine = objStreamReader.ReadLine
                txtTyreCostFactor.Text = strLine
                strLine = objStreamReader.ReadLine
                cmbBankName.Text = strLine
                strLine = objStreamReader.ReadLine
                txtPetrolPrice.Text = strLine
                objStreamReader.Close()
            End If
        Catch ex As Exception

        End Try

        Dim totalPrice As Decimal
        totalPrice = CDec(txtCarFuelFactor.Text) * CDec(txtPetrolPrice.Text) + CDec(txtServiceRepairCost.Text) + CDec(txtTyreCostFactor.Text) + CDec(txtAAFixFactor.Text)
        lblCost.Text = "( " & txtCarFuelFactor.Text & " x " & txtPetrolPrice.Text & " ) + " & txtServiceRepairCost.Text & " + " & txtTyreCostFactor.Text & " + " & txtAAFixFactor.Text & " = " & (totalPrice / 100).ToString("c")
        txtOwnerName.Focus()
        txtOwnerName.Select()
        decAAFixFactor = CDec(txtAAFixFactor.Text)
        decCarFuelFactor = txtCarFuelFactor.Text
        decServiceRepairCost = CDec(txtServiceRepairCost.Text)
        decTyreCostFactor = CDec(txtTyreCostFactor.Text)
        decPetrolPrice = CDec(txtPetrolPrice.Text)
        strAccountNum = txtAccountNum.Text
        strAdress1 = txtAdress1.Text
        strAdress2 = txtAdress2.Text
        strAdress3 = txtAdress3.Text
        strBranchNum = txtBranchNum.Text
        strOwnerName = txtOwnerName.Text
        strPostalCode = txtPostalCode.Text
        strTelephone = txtTelephone.Text
        strTypeAccount = txtTypeAccount.Text
        strBankName = cmbBankName.Text
        decCostPerKilometer = Math.Round(totalPrice / 100, 2)

        If CustomPicture <> True Then
            PictureBox1.Image = My.Resources.Joey_Logo_JPG
        Else
            Dim FS As FileStream
            FS = New FileStream(Application.StartupPath & "\MyLogo.bmp", FileMode.Open, FileAccess.Read)
            PictureBox1.Image = System.Drawing.Image.FromStream(FS)
            FS.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim totalPrice As Decimal
        totalPrice = CDec(txtCarFuelFactor.Text) * CDec(txtPetrolPrice.Text) + CDec(txtServiceRepairCost.Text) + CDec(txtTyreCostFactor.Text) + CDec(txtAAFixFactor.Text)
        lblCost.Text = "( " & txtCarFuelFactor.Text & " x " & txtPetrolPrice.Text & " ) + " & txtServiceRepairCost.Text & " + " & txtTyreCostFactor.Text & " + " & txtAAFixFactor.Text & " = " & (totalPrice / 100).ToString("c")
    End Sub

    Private Sub ExitToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem1.Click
        Dispose()
        Me.Close()
    End Sub

    Private Sub ChangeLogoPictureToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeLogoPictureToolStripMenuItem.Click, PictureBox1.Click
        openFile = New System.Windows.Forms.OpenFileDialog
        openFile.Filter = ".bmp|*.BMP|.JPG|*.JPEG"
        openFile.InitialDirectory = Application.StartupPath
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\MyLogo.bmp")
        If (openFile.ShowDialog() <> System.Windows.Forms.DialogResult.OK) Then
            Return
        End If
        inFileName = openFile.FileName.ToString
        PictureBox1.Image.Dispose()
        Try
            '' Delete the files before I copy a new one
            If fileExists Then
                File.Delete(Application.StartupPath & "\MyLogo.bmp")
            End If
            saveJPEGFile.FileName = Application.StartupPath & "\MyLogo.bmp" '& outFileName
            '' Copy the new file to the MyLogo file
            File.Copy(inFileName, saveJPEGFile.FileName, True)
            PictureBox1.Load(saveJPEGFile.FileName)
        Catch ex As Exception
            '' If file not available
            MsgBox("File is being used by another process", MsgBoxStyle.Information, "Please Note..")
        End Try
    End Sub

    Private Sub PasswordUserNameToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasswordUserNameToolStripMenuItem.Click
        Form2.ShowDialog()
    End Sub
End Class