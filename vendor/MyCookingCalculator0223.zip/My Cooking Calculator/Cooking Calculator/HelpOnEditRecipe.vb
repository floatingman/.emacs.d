﻿Imports System.Data
Imports System.IO

Public Class HelpOnEditRecipe
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub HelpOnEditRecipe_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MyRichTextBoxEx1.Rtf = ""
        Dim filename As String = "C:\My Recipes files\HelpOnEdit.rtf"
        Dim FileExists As Boolean
        FileExists = My.Computer.FileSystem.FileExists("C:\My Recipes files\HelpOnEdit.rtf")
        If Not FileExists Then
            MsgBox(" The Help file has been moved or delete, please contact Administrator", MsgBoxStyle.Information, "WARNING")
            Me.Close()
        End If
        Try
            MyRichTextBoxEx1.LoadFile(filename)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class
