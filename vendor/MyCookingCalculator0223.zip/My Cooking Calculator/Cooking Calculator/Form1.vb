﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Drawing
Imports System.Math
Imports Microsoft.VisualBasic
Imports System.Windows.Forms
Imports System.Collections
Imports System.Windows.Forms.Form

Public Class Form1
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(str)
    Public Myadp As New OleDbDataAdapter
    Public adp, ap2, adp3 As OleDbDataAdapter
    Public ds, ds1, ds2 As New DataSet
    Public dt, dt2, dt3 As New DataTable
    Public RecipeName As String = ""
    Public cmd, cmd2, cmd3, cmd4, cmd8 As OleDbCommand
    Public ROWINDEX As Integer
    Public TotalPrice As Decimal
    Public Prepcost As Decimal
    Public preptime As Decimal
    Public cooktime, TotalQuotatinPrice As Decimal
    Public RecipeNames(500) As String
    Public RecipeAmountOrdered(500) As Decimal
    Public RecipeTotal(500) As Decimal
    Public RecipeDeliveryCost(500) As Decimal
    Public RecipeDecorations(500) As Decimal
    Public RecipePrepCost(500) As Decimal

    Public Structure Ingre
        Public Name() As String
        Public Measure() As Decimal
        Public Price() As Decimal
        Public Vendor() As String
        Public Unit() As String
    End Structure

    Public Ingredient As New Ingre
    Sub RefreshListview()
        Try
            Dim dt As DataTable
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            ListBox1.Items.Clear()
            DataGridView1.DataSource = ""
            MyRichTextBoxEx1.Clear()
            dt = New DataTable
            adp = New OleDbDataAdapter("select  * from Recipe1 order by recipename ", con)
            adp.Fill(dt)
            Me.adp.Update(dt)
            Me.BindingContext(dt).EndCurrentEdit()
            Dim SqlStr As String
            SqlStr = "select  * from Recipe1 "
            cmd = New OleDbCommand(SqlStr, con)
            cmd.ExecuteNonQuery()
            adp.Fill(ds1)
            Dim counter As Integer = 0
            For Each Row As DataRow In ds1.Tables(0).Rows
                Dim Recipe(2) As String
                Me.ListBox1.Items.Add(dt.Rows(counter)(UCase("RecipeName")))
                counter = counter + 1
            Next
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        Catch ex As Exception
            ' MsgBox(ex.Message)
        End Try
    End Sub
    Sub RefreshScreen()
        Try
            dt = New DataTable
            adp = New OleDbDataAdapter("select  * from Recipe1 order by recipename ", con)
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            adp.Fill(dt)
            adp.Fill(ds1)
            Position = (Me.BindingContext(dt).Position)
            RecordCounter = ds1.Tables(0).Rows.Count
            Me.BindingContext(dt).Position = Me.BindingContext(dt).Count
            Dim counter As Integer = 0
            For Each Row As DataRow In ds1.Tables(0).Rows
                Dim Recipe(2) As String
                Me.ListBox1.Items.Add(dt.Rows(counter)(UCase("RecipeName")))
                Me.cmbMainInge_find.Items.Add(dt.Rows(counter)(UCase("MainIngredient")))
                For i As Int16 = 0 To Me.cmbMainInge_find.Items.Count - 2
                    For j As Int16 = Me.cmbMainInge_find.Items.Count - 1 To i + 1 Step -1
                        If Me.cmbMainInge_find.Items(i).ToString = Me.cmbMainInge_find.Items(j).ToString Then
                            Me.cmbMainInge_find.Items.RemoveAt(j)
                        End If
                    Next
                Next
                counter = counter + 1
            Next
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            Me.cmbMainInge_find.Text = Me.cmbMainInge_find.Items(0).ToString
            If CheckFile() Then
                '' Count the lines in the Ingredients file
                Dim sr As New StreamReader(Application.StartupPath & "\Recipe.rec")
                Dim lineCount As Integer = System.Text.RegularExpressions.Regex.Split(sr.ReadToEnd(), Environment.NewLine).Length
                Ingredient.Name = New String(lineCount) {}
                Ingredient.Price = New Decimal(lineCount) {}
                Ingredient.Vendor = New String(lineCount) {}
                Ingredient.Measure = New Decimal(lineCount) {}
                Ingredient.Unit = New String(lineCount) {}
                sr.Close()
                LoadIngredients()
            End If
            cmbCategory.Text = cmbCategory.Items(0)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        ListBox1.SelectedItem = ListBox1.Items(0)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Enabled = False
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\Username.txt")
        If fileExists Then
            objStreamReader = New StreamReader(Application.StartupPath & "\Username.txt")
            StrUserName = objStreamReader.ReadLine
            StrPassword = objStreamReader.ReadLine
            objStreamReader.Close()
            If StrUserName = "NO-USER" And StrPassword = "NO-PASS" Then
                Me.Enabled = True
            Else
                Form3.ShowDialog()
            End If
        Else
            My.Computer.FileSystem.WriteAllText(Application.StartupPath & "\Username.txt", String.Empty, False)
            Dim objStreamWrite As New StreamWriter(Application.StartupPath & "\Username.txt")
            objStreamWrite.WriteLine("USER1")
            objStreamWrite.WriteLine("PASS1")
            objStreamWrite.Close()
            MsgBox("PROGRAM IS GOING TO CLOSE NOW... PASSWORD FILE WAS DELETED")
            End
        End If
        LoadPersonalDetail()
        Me.Location = New Point((Screen.PrimaryScreen.Bounds.Width - Me.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - Me.Height) / 2)
        SplitContainer8.Panel1Collapsed = True
        ' CreateTable()
        RefreshScreen()
        CheckBox1.Visible = False
        HelpProvider1.SetHelpString(ListBox1, "You should click this button to calculate" & vbCr & " the final cost of a recipe")
        'button2 needs to have focus to display this string when F1 is pressed

    End Sub

    ''close program
    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        Dispose()
        Me.Close()
    End Sub

    '' Load ingredients into listview from RECIPE.REC file
    Sub LoadIngredients()
        Dim counter As Integer = 1
        Dim lines As String() = IO.File.ReadAllLines(Application.StartupPath & "\Recipe.rec")
        Dim objStreamReader As StreamReader
        Dim strLine As String = ""

        objStreamReader = New StreamReader(Application.StartupPath & "\Recipe.rec")
        strLine = objStreamReader.ReadLine
        a6 = strLine.Length
        a1 = strLine.IndexOf("/")
        a2 = strLine.IndexOf("/", a1 + 1)
        a3 = strLine.IndexOf("/", a2 + 1)
        a4 = strLine.IndexOf("/", a3 + 1)
        a5 = strLine.IndexOf("/", a4 + 1)
        Ingredient.Name(0) = strLine.Substring(0, a1)
        Ingredient.Price(0) = strLine.Substring(a1 + 1, a2 - a1 - 1)
        Ingredient.Vendor(0) = strLine.Substring(a2 + 1, a3 - a2 - 1)
        Ingredient.Measure(0) = strLine.Substring(a3 + 1, a4 - a3 - 1)
        Ingredient.Unit(0) = strLine.Substring(a4 + 1, a6 - a4 - 1)
        Do While Not strLine Is Nothing
            strLine = objStreamReader.ReadLine
            If counter < CInt(lines.Length) Then
                a1 = strLine.IndexOf("/")
                a2 = strLine.IndexOf("/", a1 + 1)
                a3 = strLine.IndexOf("/", a2 + 1)
                a4 = strLine.IndexOf("/", a3 + 1)
                a5 = strLine.IndexOf("/", a4 + 1)
                a6 = strLine.Length
                Ingredient.Name(counter) = Trim(strLine.Substring(0, a1))
                Ingredient.Price(counter) = Trim(strLine.Substring(a1 + 1, a2 - a1 - 1))
                Ingredient.Vendor(counter) = Trim(strLine.Substring(a2 + 1, a3 - a2 - 1))
                Ingredient.Measure(counter) = Trim(strLine.Substring(a3 + 1, a4 - a3 - 1))
                Ingredient.Unit(counter) = Trim(strLine.Substring(a4 + 1, a6 - a4 - 1))
                counter = counter + 1
            End If
        Loop

        For a = 0 To counter - 1
            Dim ListString(5) As String
            ListString(0) = Ingredient.Name(a)
            ListString(1) = Ingredient.Price(a)
            ListString(2) = Ingredient.Vendor(a)
            ListString(3) = Ingredient.Measure(a)
            ListString(4) = Ingredient.Unit(a)
            Dim itm As New ListViewItem(ListString)
            Me.ListView6.Items.Add(itm)
        Next
        objStreamReader.Close()
        Console.ReadLine()
    End Sub

    '' Split ingredients 
    Public Function IngeDetail(ByVal Surname As String) As String
        If Surname <> "" Then
            Dim SurnameArray() As String = Surname.Split(" ")
            Return SurnameArray(0)
        Else
            Return ""
        End If
    End Function

    '' Check if Ingredients file Exists
    Public Function CheckFile() As Boolean
        Dim fileExists As Boolean
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\Recipe.rec")
        If fileExists Then
            Return True
        Else
            My.Computer.FileSystem.WriteAllText(Application.StartupPath & "\Recipe.rec", String.Empty, False)
            Return False
        End If
    End Function
    

    '' Search for Recipe
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ListBox1.Items.Clear()
        DataGridView1.DataSource = ""

        Dim Dt As New DataTable
        Dt = New DataTable
        Dim DS2 As New DataSet
        DS2 = New DataSet
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Category = cmbCategory.Text
        Dim SQLStr As String = "select * from Recipe1 "
        Dim Book As String = txtBook.Text
        Dim CreatedBy As String = cmbRecipeBy.Text

        If Category = "**ALL**" And CreatedBy = "" And Book = "" Then
            SQLStr = "select * from Recipe1 "
        End If

        If Category <> "**ALL**" And CreatedBy <> "" And Book = "" Then
            SQLStr = "select * from Recipe1 where [Category] = '" & Category & "'  and [RecipeBy] = '" & CreatedBy & "' "
        End If

        If Category = "**ALL**" And CreatedBy <> "" And Book = "" Then
            SQLStr = "select * from Recipe1 where [RecipeBy] = '" & CreatedBy & "' "
        End If

        If Category <> "**ALL**" And CreatedBy <> "" And Book <> "" Then
            SQLStr = "select * from Recipe1 where [Category] = '" & Category & "'  and [RecipeBy] = '" & CreatedBy & "'  and [Book] = '" & txtBook.Text & "' "
        End If
        If Category <> "**ALL**" And CreatedBy = "" And Book <> "" Then
            SQLStr = "select * from Recipe1 where [Category] = '" & Category & "'   and [Book] = '" & txtBook.Text & "' "
        End If

        If Category <> "**ALL**" And CreatedBy = "" And Book = "" Then
            SQLStr = "select * from Recipe1 where [Category] = '" & Category & "'  "
        End If

        If Category = "**ALL**" And CreatedBy = "" And Book <> "" Then
            SQLStr = "select * from Recipe1 where = [Book] = '" & txtBook.Text & "' "
        End If
        Myadp = New OleDbDataAdapter(SQLStr, con)
        Myadp.Fill(ds2)
        Myadp.Fill(Dt)
        Dim counter As Integer = 0
        For Each Row As DataRow In Ds2.Tables(0).Rows
            ListBox1.Items.Add(Dt.Rows(counter)(UCase("RecipeName")))
            counter = counter + 1
        Next
        ds2.Dispose()
        Dt.Dispose()

        con.Close()
    End Sub

    '' Add New Recipe ...Form Called
    Private Sub AddNewRecipeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewRecipeToolStripMenuItem.Click
        ToolStripStatusLabel1.Text = "ADDING NEW RECIPE..."
        Dim ListIndex As Integer
        AddRecipes.ShowDialog()
        RefreshListview()
        ListIndex = ListBox1.Items.Count - 1
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    '' Add Ingredients
    Private Sub AddIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddIngredientToolStripMenuItem.Click
        AddIngredients.ShowDialog()
        If AddIngredients.Cancel <> True Then
            If AddIngredients.txtIngredientName.Text <> "" Then
                Dim lv As ListViewItem = ListView6.Items.Add(AddIngredients.txtIngredientName.Text)
                Dim Price As Decimal = AddIngredients.txtPriceItem.Text
                lv.SubItems.Add(Price)
                lv.SubItems.Add(AddIngredients.txtVendorName.Text)
                Dim Measure As Decimal = AddIngredients.txtMeasure.Text
                lv.SubItems.Add(Measure)
                lv.SubItems.Add(AddIngredients.cmbUnit.Text)
            End If
        End If
        Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
        Dim objStreamWriter As StreamWriter
        Dim strline1, strline2, strline3, strline4, strline5 As String
        objStreamWriter = New StreamWriter(MyPathOfAPP)
        For b = 0 To ListView6.Items.Count - 1
            strline1 = ListView6.Items(b).SubItems(0).Text
            strline2 = ListView6.Items(b).SubItems(1).Text
            strline3 = ListView6.Items(b).SubItems(2).Text
            strline4 = ListView6.Items(b).SubItems(3).Text
            strline5 = ListView6.Items(b).SubItems(4).Text
            objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
        Next
        objStreamWriter.Close()
        'Usually the first unique colum is the root item  
    End Sub

    '' Edit Ingredients
    Private Sub EditIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditIngredientToolStripMenuItem.Click
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        If ListView6.SelectedItems.Count > 0 Then
            If ListView6.Items.Count > 0 Then 'make sure there is a selected item to modify  
                IngeName = ListView6.SelectedItems(0).SubItems(0).Text
                IngrePrice = ListView6.SelectedItems(0).SubItems(1).Text
                IngeVendor = ListView6.SelectedItems(0).SubItems(2).Text
                IngreMeasure = (ListView6.SelectedItems(0).SubItems(3).Text)
                IngeUnit = (ListView6.SelectedItems(0).SubItems(4).Text)
                EditIngredients.ShowDialog()
                ListView6.SelectedItems(0).SubItems(0).Text = EditIngredients.txtIngredientName.Text
                ListView6.SelectedItems(0).SubItems(1).Text = EditIngredients.txtPriceItem.Text
                ListView6.SelectedItems(0).SubItems(2).Text = EditIngredients.txtVendorName.Text
                ListView6.SelectedItems(0).SubItems(3).Text = EditIngredients.txtMeasure.Text
                ListView6.SelectedItems(0).SubItems(4).Text = EditIngredients.cmbUnit.Text
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline1, strline2, strline3, strline4, strline5 As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                For b = 0 To ListView6.Items.Count - 1
                    strline1 = ListView6.Items(b).SubItems(0).Text
                    strline2 = ListView6.Items(b).SubItems(1).Text
                    strline3 = ListView6.Items(b).SubItems(2).Text
                    strline4 = ListView6.Items(b).SubItems(3).Text
                    strline5 = ListView6.Items(b).SubItems(4).Text
                    objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
                Next
                objStreamWriter.Close()
            End If
        Else
            MsgBox("Please select Ingredient Item and then choose Edit Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    ' Delete Ingredient
    Private Sub DeleteIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteIngredientToolStripMenuItem.Click
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        Dim DeleteThisItem As String = ListView6.SelectedItems(0).Text
        If ListView6.SelectedItems.Count > 0 Then  'make sure there is a selected item to delete  
            If MessageBox.Show("Do you want to delete this item?", "Confirm", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                ListView6.SelectedItems(0).Remove()
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline1, strline2, strline3, strline4, strline5 As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                For b = 0 To ListView6.Items.Count - 1
                    strline1 = ListView6.Items(b).SubItems(0).Text
                    strline2 = ListView6.Items(b).SubItems(1).Text
                    strline3 = ListView6.Items(b).SubItems(2).Text
                    strline4 = ListView6.Items(b).SubItems(3).Text
                    strline5 = ListView6.Items(b).SubItems(4).Text
                    objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
                Next
                objStreamWriter.Close()
            End If
            con.Open()
            Dim strSQL2 As String = "DELETE *  FROM Ingredients  WHERE [IngreName]  = '" & DeleteThisItem & "'"
            cmd7 = New OleDbCommand(strSQL2, con)
            cmd7.ExecuteNonQuery()
            con.Close()
            RefreshListview()
            ListBox1.SelectedItem = ListBox1.Items(ListIndex)
        Else
            MsgBox("Please select Ingredient Item and then choose Delete Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
    End Sub

    '' Save Ingredients
    Private Sub SaveIngredients_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
        Dim objStreamWriter As StreamWriter
        Dim strline1, strline2, strline3, strline4, strline5 As String
        objStreamWriter = New StreamWriter(MyPathOfAPP)
        For b = 0 To ListView6.Items.Count - 1
            strline1 = ListView6.Items(b).SubItems(0).Text
            strline2 = ListView6.Items(b).SubItems(1).Text
            strline3 = ListView6.Items(b).SubItems(2).Text
            strline4 = ListView6.Items(b).SubItems(3).Text
            strline5 = ListView6.Items(b).SubItems(4).Text
            objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
        Next
        objStreamWriter.Close()
    End Sub

    ''Delete Recipe
    Private Sub DeleteCurrentRecipeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteCurrentRecipeToolStripMenuItem.Click
        Dim strSQL As String
        Dim cmd7 As OleDbCommand
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim myresponse As Integer
        myresponse = MessageBox.Show("YOU ARE ABOUT TO DELETE RECIPE : " & UCase(ListBox1.SelectedItem).ToString & vbCr & vbCr & " ARE YOU SURE ABOUT THIS ?", "DELETE WARNING..!", MessageBoxButtons.YesNo, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button2)
        If myresponse = vbNo Then
            Exit Sub
        End If
        Dim strSQL2 As String = "DELETE   FROM Ingredients  WHERE [recipename]  = '" & ListBox1.SelectedItem.ToString & "'"
        cmd7 = New OleDbCommand(strSQL2, con)
        cmd7.ExecuteNonQuery()
        strSQL = "DELETE   FROM Recipe1  WHERE [RecipeName] = '" & ListBox1.SelectedItem.ToString & "'  "
        cmd8 = New OleDbCommand(strSQL, con)
        cmd8.ExecuteNonQuery()
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Close()
        cmd7.Dispose()
        cmd8.Dispose()
        DataGridView1.DataSource = ""
        MyRichTextBoxEx1.Clear()
        ListBox1.Items.Clear()
        RefreshListview()
        ListIndex = ListBox1.Items.Count - 1
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    '' Search Panel CLose
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        SplitContainer8.Panel1Collapsed = True
        ToolStripStatusLabel1.Text = "Current Recipe : " & ListBox1.SelectedItem.ToString
    End Sub
    '' Search Panel open
    Private Sub ToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem1.Click
        ToolStripStatusLabel1.Text = "Search for a Recipe in the Database using criteria"
        SplitContainer8.Panel1Collapsed = False
    End Sub

    'Add new ingredient to list
    Private Sub AddNewIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewIngredientToolStripMenuItem.Click
        ToolStripStatusLabel1.Text = "EDIT CURRENT RECIPE : " & (UCase(ListBox1.SelectedItem.ToString))
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        Try
            EditRecipe.ShowDialog()
        Catch ex As Exception
            MsgBox("PLEASE SELECT A RECIPE BEFORE YOU TRY TO EDIT")
        End Try

        DataGridView1.DataSource = ""
        MyRichTextBoxEx1.Clear()
        ' ListBox1.SelectedItems.Item(0) = True
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    ''Layout Horizontal
    Private Sub LAYOUT1HORIZONTALToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAYOUT1HORIZONTALToolStripMenuItem.Click
        SplitContainer3.Orientation = Orientation.Horizontal
        SplitContainer3.SplitterDistance = 250
        SplitContainer3.Panel2MinSize = 250
    End Sub

    '' Layout Vertical
    Private Sub LAYOUT2VERTICALToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LAYOUT2VERTICALToolStripMenuItem.Click
        SplitContainer3.Orientation = Orientation.Vertical
        SplitContainer3.SplitterDistance = 650
        SplitContainer3.Panel2MinSize = 250
    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        ToolStripStatusLabel1.Text = "EDIT CURRENT RECIPE : " & (UCase(ListBox1.SelectedItem.ToString))
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        Try
            EditRecipe.ShowDialog()
        Catch ex As Exception
            MsgBox("PLEASE SELECT A RECIPE BEFORE YOU TRY TO EDIT")
        End Try

        DataGridView1.DataSource = ""
        MyRichTextBoxEx1.Clear()
        ' ListBox1.SelectedItems.Item(0) = True
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged
        PrintCurrentRecipeToolStripMenuItem1.Text = "Print Current Recipe"
        SaveRecipeToolStripMenuItem.Text = "Save Recipe"
        Label4.Text = "RECIPE STEPS"
        DataGridView1.DataSource = ""
        MyRichTextBoxEx1.Clear()
        Dim dt As New DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        CheckBox1.Checked = False
        CheckBox1.Enabled = False
        Dim RecipeName As String = ""
        RecipeName = ListBox1.SelectedItem.ToString
        ToolStripStatusLabel1.Text = "Current Recipe : " & RecipeName
        adp2 = New OleDbDataAdapter("SELECT * FROM Ingredients where RecipeName = '" & RecipeName & "' ", con)
        adp2.fill(dt)
        lblRecipeName.Text = (CStr(dt.Rows(0)(UCase("RecipeName"))) & " : INGREDIENTS OF RECIPE").ToUpper
        DataGridView1.DataSource = dt
        dt.Columns.Add()
        dt.Columns.Add()
        dt.Columns.Add()
        With DataGridView1.Columns
            .Item(0).Visible = False
            .Item(1).HeaderText = "Ingredient Name"
            .Item(1).Width = 110
            .Item(2).HeaderText = "Preparation Comment"
            .Item(2).Width = 210
            .Item(3).HeaderText = "Ingredient Mass"
            .Item(4).HeaderText = "Ingredient Amount"
            .Item(4).Width = 55
            .Item(5).HeaderText = "Ingredient Unit"
            .Item(5).Width = 55
            .Item(6).Width = 55
            .Item(6).HeaderText = "Vendor Price"
            .Item(7).Width = 55
            .Item(7).HeaderText = "Vendor Unit"
            .Item(8).Width = 55
            .Item(8).HeaderText = "Vendor Measure"
        End With
        DataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single
        Dim myCom As New OleDbCommand
        adp3 = New OleDbDataAdapter("SELECT * FROM Recipe1 where RecipeName = '" & RecipeName & "' ", con)
        adp3.Fill(dt2)
        record = dt2.Rows.Count - 1
        AddImage()
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 12, FontStyle.Underline))
        MyRichTextBoxEx1.SelectedText = vbCr & " ---  RECIPE FROM : COOKING CALCULATOR ---"
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "RECIPE NAME : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(0)) & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "CATEGORY : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(1)) & vbCr
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "TIME COOK : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(2)) & " min     "
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = " PREPERATION TIME : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        preptime = (dt2.Rows(record).Item(9))
        cooktime = (dt2.Rows(record).Item(2))
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(9)) & " min" & vbCr
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "TEMPERATURE : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(8)) & vbCr
        ' MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        ' MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "RECIPE BY : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(4)) & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "SERVES : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 10, FontStyle.Regular))
        MyRichTextBoxEx1.SelectedText = (dt2.Rows(record).Item(7)) & " " & dt2.Rows(record).Item(10) & vbCr
        Dim Datacounter As Integer = DataGridView1.RowCount
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "INGREDIENTS : " & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        Dim Prepcomments As String = ""
        Dim aa As Integer = 0
        For aa = 0 To dt.Rows.Count - 1
            Dim Meassure As Decimal = 0
            If (dt.Rows(aa).Item(3)) = 0 Then
                Meassure = (dt.Rows(aa).Item(4))
            Else
                Meassure = (dt.Rows(aa).Item(3))
            End If
            If dt.Rows(aa).Item(2) <> "" Then
                Prepcomments = ".......   " & dt.Rows(aa).Item(2)
            End If
            MyRichTextBoxEx1.SelectionFont = (New Font("Arial Regular", 10, FontStyle.Regular))
            MyRichTextBoxEx1.SelectedText = (aa + 1) & ".         " & Meassure.ToString.PadRight(10, " ") & vbTab & (dt.Rows(aa).Item(5)) & vbTab & (dt.Rows(aa).Item(1)).ToString
            MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 8, FontStyle.Regular))
            MyRichTextBoxEx1.SelectedText = Prepcomments & vbCr
            Prepcomments = ""
        Next
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "BASIC STEPS :" & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        Dim str() As String
        Dim counter As Integer = 1
        str = (dt2.Rows(record).Item(3)).split("#")
        For i As Integer = 0 To str.Length - 1 Step 1
            If str(i) <> "" Then
                MyRichTextBoxEx1.SelectionColor = Color.Red
                MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 9, FontStyle.Regular))
                MyRichTextBoxEx1.SelectedText = counter & " :  " & Trim(str(i)) & vbCr
                counter = counter + 1
            End If
        Next
        For b = 0 To Datacounter - 1
            lvItem = ListView6.FindItemWithText(DataGridView1.Rows(b).Cells(1).Value, False, 0, True)
            If (lvItem IsNot Nothing) Then
                If DataGridView1.Rows(b).Cells(1).Value <> "" Then
                    DataGridView1.Rows(b).Cells(6).Value = lvItem.SubItems(1).Text
                    DataGridView1.Rows(b).Cells(7).Value = lvItem.SubItems(4).Text
                    DataGridView1.Rows(b).Cells(8).Value = lvItem.SubItems(3).Text
                End If
            End If
        Next
        CheckBox1.Visible = True
        CheckBox1.Checked = False
        adp3.Dispose()
        dt2.Dispose()
        con.Close()
    End Sub

    Private Sub btnCalculateRecipePrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculateRecipePrice.Click, Label16.Click
        CheckBox1.Visible = True
        CheckBox1.Font = New Font(CheckBox1.Font.FontFamily, 18, CheckBox1.Font.Style)
        CheckBox1.ForeColor = Color.Red
        Dim Totalprice As Decimal
        Dim PricePerUnit As Decimal
        Dim Recipeprice As Decimal
        Dim Decfactor As Decimal = 0
        CheckBox1.Enabled = True
        For b = 0 To DataGridView1.RowCount - 2
            If Trim(DataGridView1.Rows(b).Cells(7).Value) = "Kg" Or Trim(DataGridView1.Rows(b).Cells(7).Value) = "Liter" Then
                Decfactor = CDec(DataGridView1.Rows(b).Cells(8).Value) * 1000
            Else
                Decfactor = CDec(DataGridView1.Rows(b).Cells(8).Value)
            End If

            PricePerUnit = CDec(DataGridView1.Rows(b).Cells(6).Value) / Decfactor

            If DataGridView1.Rows(b).Cells(5).Value = "Cup" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then

                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 250))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Cup" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 250))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "ml" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value)))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "ml" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value)))
            End If

            If DataGridView1.Rows(b).Cells(5).Value = "Gram" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value)))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Gram" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value)))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Pinch" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 1))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Pinch" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 1))
            End If
            ' Halve Cup
            If DataGridView1.Rows(b).Cells(5).Value = "Halve Cup" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 125))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Halve Cup" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 125))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Tablespoon" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 15))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Tablespoon" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 15))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Teaspoon" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 5))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Teaspoon" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 5))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Q/Cup" And DataGridView1.Rows(b).Cells(3).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(3).Value) * 5))
            End If
            If DataGridView1.Rows(b).Cells(5).Value = "Q/Cup" And DataGridView1.Rows(b).Cells(4).Value <> 0 Then
                Recipeprice = PricePerUnit * ((CDec(DataGridView1.Rows(b).Cells(4).Value) * 5))
            End If
            Totalprice = Totalprice + Recipeprice
        Next
        Dim DecorationCost As Decimal = CDec(txtDecorationsPrice.Text)
        Dim ProfitPercent As Decimal = CDec(txtProfitPercent.Text)
        Dim AmountOrdered As Decimal = CInt(txtAmountOrdered.Text)
        Dim Delivercost As Decimal = Math.Round((CDec(txtDeliveryDistance.Text) * decCostPerKilometer), 0).ToString("C")
        Dim PrepCost As Decimal = (CDec(preptime) * CDec(txtPrepTimeFactor.Text)) + (CDec(cooktime) * CDec(txtCookTimeFacator.Text))
        Dim SingleRecipePrice As Decimal
        lblDeliveryCost.Text = Delivercost
        txtPrepCost.Text = Math.Round(PrepCost, 0).ToString("C")
        lblCostIngredients.Text = Totalprice.ToString("C")
        TotalQuotatinPrice = Math.Round((((((PrepCost + DecorationCost + (Totalprice * ProfitPercent / 100) + Totalprice))))), 0).ToString("C") '  price without delivery cost and Amountordered
        SingleRecipePrice = (PrepCost + DecorationCost + (Totalprice * ProfitPercent) / 100) + Totalprice
        Dim SellingPrice As Decimal = ((((((PrepCost + DecorationCost + (Totalprice * ProfitPercent) / 100) + Totalprice))) * AmountOrdered)) + Delivercost
        lblSellingPrice.Text = Math.Round(SellingPrice, 0).ToString("C")
    End Sub

    Sub PrintRecipe()
        If MyRichTextBoxEx1.Lines.Count < 2 Then
            MsgBox("RichTextbox is Empty, nothing to print", MsgBoxStyle.OkOnly, "Nothing to Print")
            Exit Sub
        End If
        If PrintDialog1.ShowDialog = DialogResult.OK Then
            MyRichTextBoxEx1.PrintRichTextContents()
        End If
    End Sub

    Private Sub PrintCurrentRecipeToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintCurrentRecipeToolStripMenuItem1.Click
        PrintRecipe()
    End Sub
    Private Sub PrintDocument1_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Static intCurrentChar As Int32
        Dim font As New Font("Verdana", 6)
        Dim PrintAreaHeight, PrintAreaWidth, marginLeft, marginTop As Int32
        With PrintDocument1.DefaultPageSettings
            PrintAreaHeight = .PaperSize.Height - .Margins.Top - .Margins.Bottom
            PrintAreaWidth = .PaperSize.Width - .Margins.Left - .Margins.Right
            marginLeft = .Margins.Left
            marginTop = .Margins.Top
        End With

        If PrintDocument1.DefaultPageSettings.Landscape Then
            Dim intTemp As Int32
            intTemp = PrintAreaHeight
            PrintAreaHeight = PrintAreaWidth
            PrintAreaWidth = intTemp
        End If
        Dim intLineCount As Int32 = CInt(PrintAreaHeight / font.Height)
        Dim rectPrintingArea As New RectangleF(marginLeft, marginTop, PrintAreaWidth, PrintAreaHeight)
        Dim fmt As New StringFormat(StringFormatFlags.LineLimit)
        Dim intLinesFilled, intCharsFitted As Int32
        e.Graphics.MeasureString(Mid(MyRichTextBoxEx1.Text, intCurrentChar + 1), font, New SizeF(PrintAreaWidth, PrintAreaHeight), fmt, intCharsFitted, intLinesFilled)
        e.Graphics.DrawString(Mid(MyRichTextBoxEx1.Text, intCurrentChar + 1), font, Brushes.Black, rectPrintingArea, fmt)
        intCurrentChar += intCharsFitted
        If intCurrentChar < e.HasMorePages = True Then
            e.HasMorePages = True
        Else
            e.HasMorePages = False
            intCurrentChar = 0
        End If
    End Sub

    Sub SaveRecipe()
        If MyRichTextBoxEx1.Lines.Count < 2 Then
            MsgBox("RichTextbox is Empty, nothing to Save", MsgBoxStyle.OkOnly, "Nothing to Save")
            Exit Sub
        End If
        Dim folderExists As Boolean
        Dim savePath As String = ""

        folderExists = My.Computer.FileSystem.DirectoryExists("C:\My Recipes files")
        If Not folderExists Then
            My.Computer.FileSystem.CreateDirectory("C:\My Recipes files")
        End If
        With SaveFile
            .AddExtension = True
            .Title = "Save the Recipe as a Richtext File!"
            .Filter = "Richtextbox files only (.rtf)|*.rtf"
            .InitialDirectory = "C:\My Recipes files"
            .ShowDialog()
            savePath = .FileName
        End With
        Try
            MyRichTextBoxEx1.SaveFile(savePath)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SaveRecipeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveRecipeToolStripMenuItem.Click
        SaveRecipe()
    End Sub

    Private Sub PrintCurrentRecipeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintCurrentRecipeToolStripMenuItem.Click
        PrintRecipe()
    End Sub

    Private Sub SaveCurrentRecipeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveCurrentRecipeToolStripMenuItem.Click
        SaveRecipe()
    End Sub

    Private Sub CheckBox1_CheckStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckStateChanged
        Dim Removed As Boolean = False
        Dim Removedatpos As Integer = 0
        If CheckBox1.Checked = True Then
            If ListBox1.SelectedItems.Count = 0 Then
                Exit Sub
            End If
            If ListBox1.SelectedItem.ToString = "" Then
                Exit Sub
            Else
                CheckedListBox1.Items.Add(ListBox1.SelectedItem.ToString)
            End If
            For i As Int16 = 0 To CheckedListBox1.Items.Count - 2
                For j As Int16 = CheckedListBox1.Items.Count - 1 To i + 1 Step -1
                    If CheckedListBox1.Items(i).ToString = CheckedListBox1.Items(j).ToString Then
                        CheckedListBox1.Items.RemoveAt(j)
                        Removed = True
                        Removedatpos = i
                    End If
                Next
            Next
            Dim counter As Integer
            If Not removed Then
                counter = CheckedListBox1.Items.Count - 1
                CheckedListBox1.Items.Item(counter).ToString()
                RecipeNames(counter) = CheckedListBox1.Items.Item(counter).ToString
                RecipeAmountOrdered(counter) = CDec(txtAmountOrdered.Text)
                RecipeTotal(counter) = TotalQuotatinPrice
                RecipeDeliveryCost(counter) = CDec(lblDeliveryCost.Text)
                RecipeDecorations(counter) = CDec(txtDecorationsPrice.Text)
                RecipePrepCost(counter) = CDec(txtPrepCost.Text)
                ' CheckedListBox1.Items(counter) = CheckState.Checked = True
            Else
                CheckedListBox1.Items.Item(Removedatpos).ToString()
                RecipeNames(Removedatpos) = CheckedListBox1.Items.Item(Removedatpos).ToString
                RecipeAmountOrdered(Removedatpos) = CDec(txtAmountOrdered.Text)
                RecipeTotal(Removedatpos) = TotalQuotatinPrice
                RecipeDeliveryCost(Removedatpos) = CDec(lblDeliveryCost.Text)
                RecipeDecorations(Removedatpos) = CDec(txtDecorationsPrice.Text)
                RecipePrepCost(Removedatpos) = CDec(txtPrepCost.Text)
                ' CheckedListBox1.Items(Removedatpos) = CheckState.Checked = True
            End If
            CheckBox1.Visible = False
            CheckBox1.Font = New Font(CheckBox1.Font.FontFamily, 14, CheckBox1.Font.Style)
            CheckBox1.ForeColor = Color.Black
        End If
    End Sub

    Private Sub CheckedListBox1_ItemCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemCheckEventArgs) Handles CheckedListBox1.ItemCheck
        If CheckedListBox1.CheckedItems.Count <> 0 Then
            PrintQuotationsToolStripMenuItem.Enabled = True
        Else
            PrintQuotationsToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub CheckedListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckedListBox1.SelectedIndexChanged
        If CheckedListBox1.CheckedItems.Count = 0 Then
            PrintQuotationsToolStripMenuItem.Enabled = False
        Else
            PrintQuotationsToolStripMenuItem.Enabled = True
        End If
    End Sub

    Private Sub CheckedListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckedListBox1.SelectedValueChanged
        If CheckState.Checked = CheckState.Checked Then
            PrintQuotationsToolStripMenuItem.Enabled = True
            ShowQuotationToolStripMenuItem.Enabled = True
        Else
            PrintQuotationsToolStripMenuItem.Enabled = False
            ShowQuotationToolStripMenuItem.Enabled = False
        End If
        If CheckedListBox1.CheckedItems.Count = 0 Then
            PrintQuotationsToolStripMenuItem.Enabled = False
            ShowQuotationToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub ClearItemsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearItemsToolStripMenuItem.Click
        ReDim RecipeNames(500)
        ReDim RecipeAmountOrdered(500)
        ReDim RecipeTotal(500)
        ReDim RecipeDeliveryCost(500)
        ReDim RecipeDecorations(500)
        ReDim RecipePrepCost(500)
        CheckedListBox1.Items.Clear()
    End Sub

    Private Sub PrintQuotationsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintQuotationsToolStripMenuItem.Click
        PrintQuotation.ShowDialog()
    End Sub

    Private Sub LoadOldQuotationsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadOldQuotationsToolStripMenuItem.Click
        SaveRecipeToolStripMenuItem.Text = "Save Quotation"
        PrintCurrentRecipeToolStripMenuItem1.Text = "Print Current Quotation"
        Label4.Text = "Quotation - loaded"
        MyRichTextBoxEx1.Rtf = ""
        folderExists = My.Computer.FileSystem.DirectoryExists("C:\My Recipes files\Quotations")
        If Not folderExists Then
            My.Computer.FileSystem.CreateDirectory("C:\My Recipes files\Quotations")
        End If
        Try
            With OpenFileDialog1
                .AddExtension = True
                .Title = "Open the Quotions as a Quotation File!"
                .Filter = "Quotation files (.rtf)|*.rtf"
                .InitialDirectory = "C:\My Recipes files\Quotations\"
                .ShowDialog()
                savePath = .FileName
            End With
            MyRichTextBoxEx1.LoadFile(OpenFileDialog1.FileName)
        Catch ex As Exception
            MsgBox("File was not opened..", MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub txtProfitPercent_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtProfitPercent.Validating
        If txtProfitPercent.Text = "" Then
            txtProfitPercent.Text = 10
        End If
        If Not IsNumeric(txtProfitPercent.Text) Then
            txtProfitPercent.Text = 10
        End If
    End Sub

    Private Sub txtAmountOrdered_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtAmountOrdered.Validating
        If txtAmountOrdered.Text = "" Then
            txtAmountOrdered.Text = 0
        End If
        If Not IsNumeric(txtAmountOrdered.Text) Then
            txtAmountOrdered.Text = 0
        End If
    End Sub

    Private Sub txtDecorationsPrice_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtDecorationsPrice.Validating
        If txtDecorationsPrice.Text = "" Then
            txtDecorationsPrice.Text = 0
        End If
        If Not IsNumeric(txtDecorationsPrice.Text) Then
            txtDecorationsPrice.Text = 0
        End If
    End Sub

    Private Sub txtDelivery_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtDeliveryDistance.Validating
        If txtDeliveryDistance.Text = "" Then
            txtDeliveryDistance.Text = 0
        End If
        If Not IsNumeric(txtDeliveryDistance.Text) Then
            txtDeliveryDistance.Text = 0
        End If
    End Sub

    Private Sub txtPrepCost_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPrepCost.Validating
        If txtPrepCost.Text = "" Then
            txtPrepCost.Text = 0
        End If
        If Not IsNumeric(txtDeliveryDistance.Text) Then
            txtPrepCost.Text = 0
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        For i As Int16 = 0 To CheckedListBox1.Items.Count - 2
            For j As Int16 = CheckedListBox1.Items.Count - 1 To i + 1 Step -1
                If CheckedListBox1.Items(i).ToString = CheckedListBox1.Items(j).ToString Then
                    CheckedListBox1.Items.RemoveAt(j)
                End If
            Next
        Next
    End Sub

    Public Sub AddImage()
        Dim Img As Image
        CustomPicture = My.Computer.FileSystem.FileExists(Application.StartupPath & "\MyLogo.bmp")
        If CustomPicture = True Then
            Img = Image.FromFile(Application.StartupPath & "\MyLogo.bmp")
        Else
            Img = My.Resources.Joey_Logo_JPG
        End If
        Clipboard.SetImage(Img)
        Me.MyRichTextBoxEx1.Paste()
    End Sub

    Private Sub ClearSelectedItemToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim ChecklistInd As Integer = CheckedListBox1.SelectedIndex
        CheckedListBox1.Items.RemoveAt(ChecklistInd)
    End Sub

    Private Sub SETUPPROGRAMFUELToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SETUPPROGRAMFUELToolStripMenuItem.Click
        FuelSetup.ShowDialog()
    End Sub

    Public Sub LoadPersonalDetail()
        Dim fileExists As Boolean
        fileExists = My.Computer.FileSystem.FileExists(Application.StartupPath & "\PersonalDetail.rec")

        If fileExists Then
            Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\PersonalDetail.rec")
            objStreamReader = New StreamReader(Application.StartupPath & "\PersonalDetail.rec")
            strLine = objStreamReader.ReadLine
            decAAFixFactor = CDec(strLine)
            strLine = objStreamReader.ReadLine
            strAccountNum = strLine
            strLine = objStreamReader.ReadLine
            strAdress1 = strLine
            strLine = objStreamReader.ReadLine
            strAdress2 = strLine
            strLine = objStreamReader.ReadLine
            strAdress3 = strLine
            strLine = objStreamReader.ReadLine
            strBranchNum = strLine
            strLine = objStreamReader.ReadLine
            decCarFuelFactor = CDec(strLine)
            strLine = objStreamReader.ReadLine
            strOwnerName = strLine
            strLine = objStreamReader.ReadLine
            strPostalCode = strLine
            strLine = objStreamReader.ReadLine
            decServiceRepairCost = CDec(strLine)
            strLine = objStreamReader.ReadLine
            strTelephone = strLine
            strLine = objStreamReader.ReadLine
            strTypeAccount = strLine
            strLine = objStreamReader.ReadLine
            decTyreCostFactor = CDec(strLine)
            strLine = objStreamReader.ReadLine
            strBankName = strLine
            strLine = objStreamReader.ReadLine
            decPetrolPrice = CDec(strLine)
            objStreamReader.Close()
        Else
            MsgBox("You have not created the file containing the personal detail.  Go to Main menu, choose Personal Detail, and save detail", MsgBoxStyle.Information)
        End If
        TotalPrice = Math.Round((((decCarFuelFactor * decPetrolPrice) + decServiceRepairCost + decTyreCostFactor + decAAFixFactor) / 100), 2)
        decCostPerKilometer = TotalPrice

    End Sub

    Private Sub AddNewCustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewCustomerToolStripMenuItem.Click
        AddCustomer.ShowDialog()
    End Sub

    Private Sub EditCustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditCustomerToolStripMenuItem.Click
        EditCustomer.ShowDialog()
    End Sub

    Private Sub DeleteACustomerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteACustomerToolStripMenuItem.Click
        DeleteCustomer.ShowDialog()
    End Sub

    Private Sub PrintListOfCustomersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintListOfCustomersToolStripMenuItem.Click
        'ViewCustomerDetail.ShowDialog()
    End Sub

    Private Sub PrintInviocesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintInviocesToolStripMenuItem.Click
        ViewInvoiceDetail.ShowDialog()
    End Sub

   
    Private Sub LoadRecipeFromRTFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadRecipeFromRTFToolStripMenuItem.Click
        SaveRecipeToolStripMenuItem.Text = "Save Recipe"
        PrintCurrentRecipeToolStripMenuItem1.Text = "Print Current Recipe"
        Label4.Text = "RECIPE - RE-LOADED"
        MyRichTextBoxEx1.Rtf = ""
        folderExists = My.Computer.FileSystem.DirectoryExists("C:\My Recipes files")
        If Not folderExists Then
            My.Computer.FileSystem.CreateDirectory("C:\My Recipes files")
        End If
        Try
            With OpenFileDialog1
                .AddExtension = True
                .Title = "Open the Recipe as a RTF File!"
                .Filter = "Recipe files (.rtf)|*.rtf"
                .InitialDirectory = "C:\My Recipes files"
                .ShowDialog()
                savePath = .FileName
            End With
            MyRichTextBoxEx1.LoadFile(OpenFileDialog1.FileName)
        Catch ex As Exception
            MsgBox("File was not opened..", MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub ShowQuotationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowQuotationToolStripMenuItem.Click
        PrintQuotation.ShowDialog()
    End Sub

    Private Sub ListView6_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView6.DoubleClick
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        If ListView6.SelectedItems.Count > 0 Then
            If ListView6.Items.Count > 0 Then 'make sure there is a selected item to modify  
                IngeName = ListView6.SelectedItems(0).SubItems(0).Text
                IngrePrice = ListView6.SelectedItems(0).SubItems(1).Text
                IngeVendor = ListView6.SelectedItems(0).SubItems(2).Text
                IngreMeasure = (ListView6.SelectedItems(0).SubItems(3).Text)
                IngeUnit = (ListView6.SelectedItems(0).SubItems(4).Text)
                EditIngredients.ShowDialog()
                ListView6.SelectedItems(0).SubItems(0).Text = EditIngredients.txtIngredientName.Text
                ListView6.SelectedItems(0).SubItems(1).Text = EditIngredients.txtPriceItem.Text
                ListView6.SelectedItems(0).SubItems(2).Text = EditIngredients.txtVendorName.Text
                ListView6.SelectedItems(0).SubItems(3).Text = EditIngredients.txtMeasure.Text
                ListView6.SelectedItems(0).SubItems(4).Text = EditIngredients.cmbUnit.Text
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline1, strline2, strline3, strline4, strline5 As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                For b = 0 To ListView6.Items.Count - 1
                    strline1 = ListView6.Items(b).SubItems(0).Text
                    strline2 = ListView6.Items(b).SubItems(1).Text
                    strline3 = ListView6.Items(b).SubItems(2).Text
                    strline4 = ListView6.Items(b).SubItems(3).Text
                    strline5 = ListView6.Items(b).SubItems(4).Text
                    objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
                Next
                objStreamWriter.Close()
            End If
        Else
            MsgBox("Please select Ingredient Item and then choose Edit Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    Private Sub CreateTable()
        Dim con As New OleDbConnection(str)
        Dim cmd, cmd2, cmd3, cmd4 As OleDbCommand
        Dim StrSql As String
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        StrSql = ("CREATE TABLE Recipe1 (" _
                  & "RecipeName VARCHAR(50)  NOT NULL," _
                  & "Category  VARCHAR(50)  NOT NULL," _
                  & "Time DECIMAL NOT NULL, " _
                  & "Steps MEMO, " _
                  & "RecipeBy VARCHAR(50)  NOT NULL, " _
                  & "MainIngredient VARCHAR(50)  NOT NULL, " _
                  & "CuisineStyle VARCHAR(50)  NOT NULL, " _
                  & "Serves DECIMAL NOT NULL, " _
                  & "Temp DECIMAL NOT NULL , " _
                  & "VoorBereityd DECIMAL NOT NULL  , " _
                  & "Lewer VARCHAR(50)  NOT NULL  , " _
                  & "Book VARCHAR(50)  NOT NULL )")
        cmd = New OleDbCommand(StrSql, con)
        cmd.ExecuteNonQuery()

        StrSql = ("CREATE TABLE Ingredients (" _
                  & "RecipeName VARCHAR(50)  NOT NULL," _
                  & "IngreName  VARCHAR(50)  NOT NULL," _
                  & "PrepComment VARCHAR(50)  NOT NULL, " _
                  & "IngreWeight DECIMAL NOT NULL, " _
                  & "IngreAmount DECIMAL NOT NULL, " _
                  & "IngreUnit VARCHAR(50)  NOT NULL, ")

        cmd2 = New OleDbCommand(StrSql, con)
        cmd2.ExecuteNonQuery()

        StrSql = ("CREATE TABLE Customer (" _
                  & "CustomerName VARCHAR(255)  NOT NULL," _
                  & "Adress1  VARCHAR(255)  NOT NULL," _
                  & "Adress2 VARCHAR(255)  NOT NULL, " _
                  & "Adress3 VARCHAR(255)  NOT NULL, " _
                  & "Telephone VARCHAR(5)  NOT NULL, " _
                  & "Email VARCHAR(255)  NOT NULL, " _
                  & "CompanyName VARCHAR(255)  NOT NULL ,")
        cmd3 = New OleDbCommand(StrSql, con)
        cmd3.ExecuteNonQuery()

        StrSql = ("CREATE TABLE CustomeOrder (" _
                  & "RecipeOrdered VARCHAR(255)  NOT NULL," _
                  & "AmountOrdered  DECIMAL NOT NULL," _
                  & "DateOrdered VARCHAR(12)  NOT NULL, " _
                  & "Cost DECIMAL NOT NULL, " _
                  & "CustomerName VARCHAR(255)  NOT NULL, ")
        cmd4 = New OleDbCommand(StrSql, con)
        cmd4.ExecuteNonQuery()
        con.Close()
    End Sub


    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        Dim ListIndex As Integer
        ToolStripStatusLabel1.Text = "ADDING NEW RECIPE..."
        AddRecipes.ShowDialog()
        RefreshListview()
        ListIndex = ListBox1.Items.Count - 1
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        Dim vbrespons As Integer
        vbrespons = MessageBox.Show("Would you like to delete this recipe ? ", "Delete Recipe ?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If vbrespons = vbYes Then
            Dim strSQL As String
            Dim cmd7 As OleDbCommand
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            Dim myresponse As Integer
            myresponse = MessageBox.Show("YOU ARE ABOUT TO DELETE RECIPE : " & UCase(ListBox1.SelectedItem).ToString & vbCr & vbCr & " ARE YOU SURE ABOUT THIS ?", "DELETE WARNING..!", MessageBoxButtons.YesNo, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button2)
            If myresponse = vbNo Then
                Exit Sub
            End If
            Dim strSQL2 As String = "DELETE   FROM Ingredients  WHERE [recipename]  = '" & ListBox1.SelectedItem.ToString & "'"
            cmd7 = New OleDbCommand(strSQL2, con)
            cmd7.ExecuteNonQuery()
            strSQL = "DELETE   FROM Recipe1  WHERE [RecipeName] = '" & ListBox1.SelectedItem.ToString & "'  "
            cmd8 = New OleDbCommand(strSQL, con)
            cmd8.ExecuteNonQuery()
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Close()
            cmd7.Dispose()
            cmd8.Dispose()
            DataGridView1.DataSource = ""
            MyRichTextBoxEx1.Clear()
            ListBox1.Items.Clear()
            RefreshListview()
            ListIndex = ListBox1.Items.Count - 1
            ListBox1.SelectedItem = ListBox1.Items(ListIndex)
        End If
    End Sub

    Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click
        ToolStripStatusLabel1.Text = "EDIT CURRENT RECIPE : " & (UCase(ListBox1.SelectedItem.ToString))
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        Try
            EditRecipe.ShowDialog()
        Catch ex As Exception
            MsgBox("PLEASE SELECT A RECIPE BEFORE YOU TRY TO EDIT")
        End Try
        DataGridView1.DataSource = ""
        MyRichTextBoxEx1.Clear()
        ' ListBox1.SelectedItems.Item(0) = True
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    Private Sub ToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem5.Click
        PrintRecipe()
    End Sub

    Private Sub AddNewIngredientToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewIngredientToolStripMenuItem1.Click
        AddIngredients.ShowDialog()
        If AddIngredients.Cancel <> True Then
            If AddIngredients.txtIngredientName.Text <> "" Then
                Dim lv As ListViewItem = ListView6.Items.Add(AddIngredients.txtIngredientName.Text)
                Dim Price As Decimal = AddIngredients.txtPriceItem.Text
                lv.SubItems.Add(Price)
                lv.SubItems.Add(AddIngredients.txtVendorName.Text)
                Dim Measure As Decimal = AddIngredients.txtMeasure.Text
                lv.SubItems.Add(Measure)
                lv.SubItems.Add(AddIngredients.cmbUnit.Text)
            End If
        End If
        Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
        Dim objStreamWriter As StreamWriter
        Dim strline1, strline2, strline3, strline4, strline5 As String
        objStreamWriter = New StreamWriter(MyPathOfAPP)
        For b = 0 To ListView6.Items.Count - 1
            strline1 = ListView6.Items(b).SubItems(0).Text
            strline2 = ListView6.Items(b).SubItems(1).Text
            strline3 = ListView6.Items(b).SubItems(2).Text
            strline4 = ListView6.Items(b).SubItems(3).Text
            strline5 = ListView6.Items(b).SubItems(4).Text
            objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
        Next
        objStreamWriter.Close()
        'Usually the first unique colum is the root item  
    End Sub

    Private Sub EditCurrentIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditCurrentIngredientToolStripMenuItem.Click
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        If ListView6.SelectedItems.Count > 0 Then
            If ListView6.Items.Count > 0 Then 'make sure there is a selected item to modify  
                IngeName = ListView6.SelectedItems(0).SubItems(0).Text
                IngrePrice = ListView6.SelectedItems(0).SubItems(1).Text
                IngeVendor = ListView6.SelectedItems(0).SubItems(2).Text
                IngreMeasure = (ListView6.SelectedItems(0).SubItems(3).Text)
                IngeUnit = (ListView6.SelectedItems(0).SubItems(4).Text)
                EditIngredients.ShowDialog()
                ListView6.SelectedItems(0).SubItems(0).Text = EditIngredients.txtIngredientName.Text
                ListView6.SelectedItems(0).SubItems(1).Text = EditIngredients.txtPriceItem.Text
                ListView6.SelectedItems(0).SubItems(2).Text = EditIngredients.txtVendorName.Text
                ListView6.SelectedItems(0).SubItems(3).Text = EditIngredients.txtMeasure.Text
                ListView6.SelectedItems(0).SubItems(4).Text = EditIngredients.cmbUnit.Text
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline1, strline2, strline3, strline4, strline5 As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                For b = 0 To ListView6.Items.Count - 1
                    strline1 = ListView6.Items(b).SubItems(0).Text
                    strline2 = ListView6.Items(b).SubItems(1).Text
                    strline3 = ListView6.Items(b).SubItems(2).Text
                    strline4 = ListView6.Items(b).SubItems(3).Text
                    strline5 = ListView6.Items(b).SubItems(4).Text
                    objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
                Next
                objStreamWriter.Close()
            End If
        Else
            MsgBox("Please select Ingredient Item and then choose Edit Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
        RefreshListview()
        ListBox1.SelectedItem = ListBox1.Items(ListIndex)
    End Sub

    Private Sub DeleteCurrentIngredientToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteCurrentIngredientToolStripMenuItem.Click
        Dim ListIndex As Integer = ListBox1.SelectedIndex
        Dim DeleteThisItem As String = ListView6.SelectedItems(0).Text
        If ListView6.SelectedItems.Count > 0 Then  'make sure there is a selected item to delete  
            If MessageBox.Show("Do you want to delete this item?", "Confirm", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                ListView6.SelectedItems(0).Remove()
                Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
                Dim objStreamWriter As StreamWriter
                Dim strline1, strline2, strline3, strline4, strline5 As String
                objStreamWriter = New StreamWriter(MyPathOfAPP)
                For b = 0 To ListView6.Items.Count - 1
                    strline1 = ListView6.Items(b).SubItems(0).Text
                    strline2 = ListView6.Items(b).SubItems(1).Text
                    strline3 = ListView6.Items(b).SubItems(2).Text
                    strline4 = ListView6.Items(b).SubItems(3).Text
                    strline5 = ListView6.Items(b).SubItems(4).Text
                    objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
                Next
                objStreamWriter.Close()
            End If
            con.Open()
            Dim strSQL2 As String = "DELETE *  FROM Ingredients  WHERE [IngreName]  = '" & DeleteThisItem & "'"
            cmd7 = New OleDbCommand(strSQL2, con)
            cmd7.ExecuteNonQuery()
            con.Close()
            RefreshListview()
            ListBox1.SelectedItem = ListBox1.Items(ListIndex)
        Else
            MsgBox("Please select Ingredient Item and then choose Delete Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
    End Sub
End Class
