﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class EditCustomer
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(Str)
    Public adp As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public ds As New DataSet
    Public dt As New DataTable
    Public Oldname As String = ""
    Private Sub EditCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim dt As DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        ListBox1.Items.Clear()
        dt = New DataTable
        adp = New OleDbDataAdapter("select  * from Customer ", con)
        adp.Fill(dt)
        Me.adp.Update(dt)
        Me.BindingContext(dt).EndCurrentEdit()
        Dim SqlStr As String
        SqlStr = "select  * from Customer "
        cmd = New OleDbCommand(SqlStr, con)
        cmd.ExecuteNonQuery()
        adp.Fill(ds)
        Dim counter As Integer = 0
        For Each Row As DataRow In ds.Tables(0).Rows
            Dim Recipe(2) As String
            Me.ListBox1.Items.Add(dt.Rows(counter)(UCase("CustomerName")))
            counter = counter + 1
        Next
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
    End Sub

    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged
        Dim dt As New DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim RecipeName As String = ""
        CustomerName = ListBox1.SelectedItem.ToString
        adp2 = New OleDbDataAdapter("SELECT * FROM Customer where CustomerName = '" & CustomerName & "' ", con)
        adp2.fill(dt)
        Oldname = dt.Rows(0)("CustomerName")
        txtCustomerName.Text = dt.Rows(0)("CustomerName")
        txtAdress1.Text = dt.Rows(0)("Adress1")
        txtAdress2.Text = dt.Rows(0)("Adress2")
        txtAdress3.Text = dt.Rows(0)("Adress3")
        txtTelephone.Text = dt.Rows(0)("Telephone")
        txtEMail.Text = dt.Rows(0)("Email")
        txtCompanyName.Text = dt.Rows(0)("CompanyName")
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
    End Sub

    Private Sub btnSaveDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveDetail.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        SQLStr = "UPDATE [Customer] SET  [CustomerName] = '" & txtCustomerName.Text & "'  , [Adress1] = '" & txtAdress1.Text & "' ,[Adress2] = '" & txtAdress2.Text & "' ,  [adress3] = '" & txtAdress3.Text & "' , [Telephone] = '" & txtTelephone.Text & "' , [Email] = '" & txtEMail.Text & "' , [CompanyName] = '" & txtCompanyName.Text & "' WHERE [CustomerName] = '" & Oldname & "'  "
        cmd = New OleDbCommand(SQLStr, con)
        cmd.ExecuteNonQuery()
        SQLStr = "UPDATE [CustomeOrder] SET  [CustomerName] = '" & txtCustomerName.Text & "' WHERE [CustomerName] = '" & Oldname & "'  "
        cmd = New OleDbCommand(SQLStr, con)
        cmd.ExecuteNonQuery()
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        cmd.Dispose()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Dispose()
        Me.Close()
    End Sub
End Class