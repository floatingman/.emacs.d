﻿Imports System.IO
Imports Microsoft.VisualBasic.FileIO
Public Class Form2
    Private Sub BTNEXIT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNEXIT.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        My.Computer.FileSystem.WriteAllText(Application.StartupPath & "\Username.txt", String.Empty, False)
        Dim objStreamWrite As New StreamWriter(Application.StartupPath & "\Username.txt")
        objStreamWrite.WriteLine(txtNewUserName.Text)
        objStreamWrite.WriteLine(txtNewPassword.Text)
        objStreamWrite.Close()
    End Sub
End Class