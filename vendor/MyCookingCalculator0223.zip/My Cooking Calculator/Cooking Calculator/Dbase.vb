﻿Imports System.Data
Imports System.Data.OleDb
Public Class Dbase
    Dim Rs_AppPath As String
    Public con As New OleDbConnection
    Public adp As OleDbDataAdapter
    Public dr As OleDbDataReader
    Public cmd As OleDbCommand
    Public ds As New DataSet
    Public dt As New DataTable
    Public tbl As String
    Public str As String
    Public Sub New(ByVal tbl As String)
        Rs_AppPath = System.IO.Directory.GetCurrentDirectory
        Dim str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "Recipes.mdb"
        con.ConnectionString = str
        con.Open()
        adp = New OleDbDataAdapter("select * from " & tbl, con)
        adp.Fill(ds, tbl)
        dt = ds.Tables(tbl)
        Me.tbl = tbl
    End Sub
    Public Sub save()
        Dim cmdb As New OleDbCommandBuilder(adp)
        adp.Update(ds, tbl)
    End Sub
End Class
