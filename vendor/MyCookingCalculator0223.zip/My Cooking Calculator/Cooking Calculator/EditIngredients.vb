﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class EditIngredients
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(Str)
    Public adp As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public Cancel As Boolean = False
    Public OldIngreName As String = ""
    Private Sub EditIngredients_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtIngredientName.Text = IngeName
        txtPriceItem.Text = IngrePrice
        txtVendorName.Text = IngeVendor
        txtMeasure.Text = IngreMeasure
        cmbUnit.Text = IngeUnit
        Dim X As Integer = Form1.MousePosition.X - 300
        Dim y As Integer = Form1.MousePosition.Y - 300
        Me.DesktopLocation = New Point(X, y)
        OldIngreName = txtIngredientName.Text
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If Not IsNumeric(txtPriceItem.Text) Then
            txtPriceItem.Focus()
            txtPriceItem.BackColor = Color.LightPink
            txtPriceItem.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(txtMeasure.Text) Then
            txtMeasure.Focus()
            txtMeasure.BackColor = Color.LightPink
            txtMeasure.Text = ""
            Exit Sub
        End If
        If CDec(txtMeasure.Text) = 0 And CDec(txtPriceItem.Text) = 0 Then
            MsgBox("You can not have both Measure and Weight as 0, please check and correct", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If txtIngredientName.Text <> OldIngreName And txtIngredientName.Text <> "" Then
            Dim SQLStr As String
            con.Open()
            SQLStr = "UPDATE [Ingredients] SET  [IngreName] = '" & txtIngredientName.Text & "'   WHERE [IngreName] = '" & OldIngreName & "'  "
            cmd = New OleDbCommand(SQLStr, con)
            cmd.ExecuteNonQuery()
            con.Close()
        End If

        Cancel = False
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        If Not IsNumeric(txtPriceItem.Text) Then
            txtPriceItem.Focus()
            txtPriceItem.BackColor = Color.LightPink
            txtPriceItem.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(txtMeasure.Text) Then
            txtMeasure.Focus()
            txtMeasure.BackColor = Color.LightPink
            txtMeasure.Text = ""
            Exit Sub
        End If
        Cancel = True
        Me.Close()
    End Sub


    Private Sub txtPriceItem_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPriceItem.Validating
        If txtPriceItem.Text = "" Then
            txtPriceItem.Text = 0
        End If
        If Not IsNumeric(txtPriceItem.Text) Then
            txtPriceItem.Text = 0
        End If
    End Sub

    Private Sub txtMeasure_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMeasure.TextChanged
        If txtMeasure.Text = "" Then
            txtMeasure.Text = 0
        End If
        If Not IsNumeric(txtMeasure.Text) Then
            txtMeasure.Text = 0
        End If
    End Sub
End Class