﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class EditRecipe
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(Str)
    Public adp, adp2, adp3 As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public cmd2 As OleDbCommand
    Public ds1, ds2 As New DataSet
    Public dt, dt2 As New DataTable
    Dim ds As New DataSet
    Public RecipeSteps As String
    Public RecipeName As String = Form1.ListBox1.SelectedItem.ToString
    Public OldName As String
    Private Sub EditRecipe_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ToolStripButton5.Enabled = False
        'For a = 0 To Form1.ListView6.Items.Count - 1
        '    ToolStripComboBox1.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        '    ToolStripComboBox1.Text = ToolStripComboBox1.Items(0).ToString
        'Next
        cmbMainIngre.Items.Clear()
        For a = 0 To Form1.ListView6.Items.Count - 1
            cmbMainIngre.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
        Dim dt = New DataTable
        adp = New OleDbDataAdapter("select  * from recipe1 where [recipename] = '" & RecipeName & "'", con)
        adp.Fill(dt)
        txtRecipeName.Text = CStr(dt.Rows(0)("Recipename"))
        cmbCategory.Text = dt.Rows(0)("Category")
        txtTime.Text = dt.Rows(0)("Time")
        txtRecipeBy.Text = dt.Rows(0)("Recipeby")
        cmbMainIngre.Text = dt.Rows(0)("Mainingredient")
        cmbCuzineStyle.Text = dt.Rows(0)("Cuisinestyle")
        txtServes.Text = dt.Rows(0)("Serves")
        txtTemp.Text = dt.Rows(0)("Temp")
        txtPrepTime.Text = dt.Rows(0)("Voorbereityd")
        cmbServeType.Text = dt.Rows(0)("Lewer")
        txtBook.Text = dt.Rows(0)("Book")
        Button1.Enabled = True
        For a = 0 To Form1.ListView6.Items.Count - 1
            ListBox1.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
        Button1.PerformClick()
        Button1.Visible = False
        OldName = txtRecipeName.Text
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ToolStripButton5.Enabled = True
        Button1.Enabled = False
        Dim dt = New DataTable
        adp = New OleDbDataAdapter("select  * from Ingredients where [recipename] = '" & RecipeName & "'", con)
        DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Blue
        DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
        DataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Sunken
        DataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing
        adp.Fill(dt)
        DataGridView1.DataSource = dt
        With DataGridView1.Columns
            .Item(0).Visible = False
            .Item(1).HeaderText = "Ingredient Name"
            .Item(2).HeaderText = "Preperation Comment"
            .Item(3).HeaderText = "Weight"
            .Item(4).HeaderText = "Amount"
            .Item(5).HeaderText = "Unit"
            .Item(1).Width = 100
            .Item(2).Width = 180
            .Item(3).Width = 50
            .Item(4).Width = 50
            .Item(5).Width = 50
            .Item(1).Frozen = True
        End With
        adp2 = New OleDbDataAdapter("select  * from recipe1 where [recipename] = '" & RecipeName & "'", con)
        adp2.Fill(dt2)
        Dim str() As String
        Dim counter As Integer = 1
        str = (dt2.Rows(0).Item(3)).split("#")
        For i As Integer = 0 To str.Length - 1 Step 1
            If str(i) <> "" Then
                RichTextBox1.SelectedText = (Trim(str(i)) & "#")
                RichTextBox1.SelectedText = vbCr
                counter = counter + 1
            End If
        Next
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        con.Close()
        Dispose()
        Me.Close()
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton5.Click
        Dim a As Integer = 0
        Dim RecipeSteps As String = ""
        For Each line In RichTextBox1.Lines
            If RichTextBox1.Lines(a) <> "" Then
                RecipeSteps = RecipeSteps & RichTextBox1.Lines(a)
            End If
            a = a + 1
        Next
        If txtPrepTime.Text = "" Then
            txtPrepTime.Text = 1
        End If
        If txtTime.Text = "" Then
            txtTime.Text = 1
        End If
        If txtTemp.Text = "" Then
            txtTemp.Text = 1
        End If
        If txtServes.Text = "" Then
            txtServes.Text = 1
        End If
        If cmbServeType.Text = "" Then
            cmbServeType.Text = "Cake"
        End If
        RecipeSteps = RecipeSteps.Substring(0, Len(RecipeSteps) - 1)
        Dim cmd8 As OleDbCommand
        Dim SQLStr As String
        con.Open()
        Dim strSQL As String = "DELETE   FROM Ingredients  WHERE [recipename]  = '" & OldName & "'"
        cmd8 = New OleDbCommand(strSQL, con)
        cmd8.ExecuteNonQuery()
        SQLStr = "UPDATE [Recipe1] SET  [RecipeName] = '" & txtRecipeName.Text & "'  , [Category] = '" & cmbCategory.Text & "' ,[Time] = '" & CDec(txtTime.Text) & "' ,  [Steps] = '" & RecipeSteps & "' , [RecipeBy] = '" & txtRecipeBy.Text & "' , [Mainingredient] = '" & cmbMainIngre.Text & "' , [CuisineStyle] = '" & cmbCuzineStyle.Text & "', [Serves] = '" & CDec(txtServes.Text) & "' , [Temp] = '" & CInt(txtTemp.Text) & "'  , [Voorbereityd] = '" & CDec(txtPrepTime.Text) & "' , [Lewer] = '" & cmbServeType.Text & "'  , [Book] = '" & txtBook.Text & "' WHERE [RecipeName] = '" & OldName & "'  "
        cmd = New OleDbCommand(SQLStr, con)
        cmd.ExecuteNonQuery()
        Dim dt2 = New DataTable
        cmd8.Dispose()
        cmd.Dispose()
        con.Close()
        con.Open()
        a = 0
        For Each row As DataGridViewRow In DataGridView1.Rows
            Try
                If DataGridView1.Rows(a).Cells(1).Value <> "" Then
                    SQLStr = "insert into Ingredients values('" & txtRecipeName.Text & "','" & row.Cells(1).Value & "' , '" & row.Cells(2).Value & "' , '" & CDec(row.Cells(3).Value) & "' , '" & CDec(row.Cells(4).Value) & "', '" & row.Cells(5).Value & "') "
                    adp2 = New OleDbDataAdapter(SQLStr, con)
                    adp2.Fill(dt2)
                    Me.BindingContext(dt2).EndCurrentEdit()
                    Me.adp.Update(dt2)
                    a = a + 1
                End If
            Catch ex As Exception

            End Try
        Next
        con.Close()
    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        AddIngredients.ShowDialog()
        If AddIngredients.Cancel <> True Then
            If AddIngredients.txtIngredientName.Text <> "" Then
                Dim lv As ListViewItem = Form1.ListView6.Items.Add(AddIngredients.txtIngredientName.Text)
                Dim Price As Decimal = AddIngredients.txtPriceItem.Text
                lv.SubItems.Add(Price)
                lv.SubItems.Add(AddIngredients.txtVendorName.Text)
                Dim Measure As Decimal = AddIngredients.txtMeasure.Text
                lv.SubItems.Add(Measure)
                lv.SubItems.Add(AddIngredients.cmbUnit.Text)
            End If
        End If
        Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
        Dim objStreamWriter As StreamWriter
        Dim strline1, strline2, strline3, strline4, strline5 As String
        objStreamWriter = New StreamWriter(MyPathOfAPP)
        For b = 0 To Form1.ListView6.Items.Count - 1
            strline1 = Form1.ListView6.Items(b).SubItems(0).Text
            strline2 = Form1.ListView6.Items(b).SubItems(1).Text
            strline3 = Form1.ListView6.Items(b).SubItems(2).Text
            strline4 = Form1.ListView6.Items(b).SubItems(3).Text
            strline5 = Form1.ListView6.Items(b).SubItems(4).Text
            objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
        Next
        objStreamWriter.Close()
        For a = 0 To Form1.ListView6.Items.Count - 1
            cmbMainIngre.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
    End Sub
    Private Sub ListBox1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListBox1.MouseClick
        My.Computer.Clipboard.SetText(ListBox1.SelectedItem.ToString)
    End Sub


    Private Sub ToolStrip2_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip2.ItemClicked
        If ListBox1.SelectedItems.Count > 0 Then
            My.Computer.Clipboard.SetText(ListBox1.SelectedItem.ToString)
        End If
    End Sub

    Private Sub DataGridView1_CurrentCellDirtyStateChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGridView1.CurrentCellDirtyStateChanged
        If DataGridView1.IsCurrentCellDirty Then
            DataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub
    Private Overloads Sub RichTextBox1_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RichTextBox1.KeyDown
        If e.KeyCode = Keys.Return Then
            RichTextBox1.SelectedText = "#"
        End If
    End Sub

    Private Sub DataGridView1_UserAddedRow(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowEventArgs) Handles DataGridView1.UserAddedRow
        Dim X As Integer = DataGridView1.CurrentCellAddress.X
        Dim Y As Integer = DataGridView1.CurrentCellAddress.Y
        If DataGridView1.CurrentRow().Cells(X).Value Is Nothing Then
            DataGridView1(0, DataGridView1.CurrentCell.RowIndex).Value = ListBox1.SelectedItems.ToString
        End If
        DataGridView1.CurrentRow().Cells(X + 2).Value = 1
        DataGridView1.CurrentRow().Cells(X + 3).Value = 0
        DataGridView1.CurrentRow().Cells(X + 4).Value = "ml"
    End Sub

    Private Sub Label14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label14.Click, PictureBox1.Click
        HelpOnEditRecipe.ShowDialog()
    End Sub
End Class