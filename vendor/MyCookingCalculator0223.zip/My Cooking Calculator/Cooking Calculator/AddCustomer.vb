﻿
Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class AddCustomer
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(str)
    Public adp As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public ds As New DataSet
    Public dt As New DataTable
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Dispose()
        Me.Close()
    End Sub

    Private Sub btnSaveDetail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveDetail.Click
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        dt = New DataTable
        Try
            adp = New OleDbDataAdapter("insert into Customer values('" & txtCustomerName.Text & "' , '" & txtAdress1.Text & "' , '" & txtAdress2.Text & "' ,'" & txtAdress3.Text & "','" & txtTelephone.Text & "', '" & txtEMail.Text & "' ,'" & txtCompanyName.Text & "' )", con)
            adp.Fill(dt)
            Me.BindingContext(dt).EndCurrentEdit()
            Me.adp.Update(dt)
            Me.BindingContext(dt).Position = 1
        Catch ex As Exception
            ' Dislay Message if error occur
            MsgBox("You have an ERROR, Check that the Customer Name is not Duplicated ....  ", MsgBoxStyle.Exclamation, "E R R O R   I N   D A T A B A S E !!")
            Exit Sub
        End Try
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
    End Sub
End Class