﻿
Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class ViewInvoiceDetail
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(Str)
    Public adp As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public ds, ds2 As New DataSet
    Public dt, dt2 As New DataTable
    Public Oldname As String = ""
    Public CustomerName, CustomerAdres1, CustomerAdres2, CustomerAdres3, CustomerTelephone, CustomerEmail, CompanyName As String
    Private Sub ViewInvoiceDetail_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshScreen()
    End Sub
    Sub RefreshScreen()
        Dim dt As DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        ListBox1.Items.Clear()
        Try
            dt = New DataTable
            adp = New OleDbDataAdapter("select  * from Customer ", con)
            adp.Fill(dt)
            Me.adp.Update(dt)
            Me.BindingContext(dt).EndCurrentEdit()
            Dim SqlStr As String
            SqlStr = "select  * from Customer "
            cmd = New OleDbCommand(SqlStr, con)
            cmd.ExecuteNonQuery()
            adp.Fill(ds)
            Dim counter As Integer = 0
            For Each Row As DataRow In ds.Tables(0).Rows
                Me.ListBox1.Items.Add(dt.Rows(counter)(UCase("CustomerName")))
                counter = counter + 1
            Next
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        Catch ex As Exception
            ' MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        ListBox2.Items.Clear()
        CustomerName = ListBox1.SelectedItem.ToString
        Dim adp As OleDbDataAdapter
        Dim ds, ds2 As New DataSet
        Dim dt, dt2 As New DataTable
        Try
            dt = New DataTable
            adp = New OleDbDataAdapter("SELECT   * FROM CustomeOrder where CustomerName = '" & CustomerName & "'  ", con)
            adp.Fill(dt)
            ' Me.adp.Update(dt)
            ' Me.BindingContext(dt).EndCurrentEdit()
            adp.Fill(ds)
            Dim counter As Integer = 0
            For Each Row As DataRow In ds.Tables(0).Rows
                Me.ListBox2.Items.Add(dt.Rows(counter)(UCase("DateOrdered")))
                For i As Int16 = 0 To ListBox2.Items.Count - 2
                    For j As Int16 = ListBox2.Items.Count - 1 To i + 1 Step -1
                        If ListBox2.Items(i).ToString = ListBox2.Items(j).ToString Then
                            ListBox2.Items.RemoveAt(j)
                        End If
                    Next
                Next
                counter = counter + 1
            Next
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        Catch ex As Exception
            '  MsgBox(ex.Message)

        End Try
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        ds.Dispose()
        dt.Dispose()
    End Sub

    Private Sub ListBox2_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedValueChanged
        Dim dt As New DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        MyRichTextBoxEx1.Clear()
        Dim DateOrdered As Date
        DateOrdered = ListBox2.SelectedItem.ToString
        DateOrdered = (DateOrdered.ToShortDateString).ToString
        Dim myCustomerName As String = ListBox1.SelectedItem.ToString
        AddImage()
        adp = New OleDbDataAdapter("SELECT * FROM Customer where CustomerName = '" & myCustomerName & "'  ", con)
        adp.Fill(dt)
        CustomerName = dt.Rows(0)("CustomerName")
        CustomerAdres1 = dt.Rows(0)("Adress1")
        CustomerAdres2 = dt.Rows(0)("Adress2")
        CustomerAdres3 = dt.Rows(0)("Adress3")
        CustomerTelephone = dt.Rows(0)("Telephone")
        CustomerEmail = dt.Rows(0)("Email")
        CompanyName = dt.Rows(0)("CompanyName")
        If con.State = ConnectionState.Open Then
            con.Close()
        End If

        MyRichTextBoxEx1.SelectedText = vbCr & vbCr & "Customer Name : " & CustomerName & vbCr
        MyRichTextBoxEx1.SelectedText = "Adress : " & CustomerAdres1 & vbCr
        MyRichTextBoxEx1.SelectedText = "              " & CustomerAdres2 & vbCr
        MyRichTextBoxEx1.SelectedText = "              " & CustomerAdres3 & vbCr
        MyRichTextBoxEx1.SelectedText = "Telephone Num : " & CustomerTelephone & vbCr
        MyRichTextBoxEx1.SelectedText = "Email : " & CustomerEmail & vbCr
        MyRichTextBoxEx1.SelectedText = "Company Name : " & CompanyName & vbCr & vbCr
        Dim TotalCost As Decimal
        Try
            dt2 = New DataTable
            adp = New OleDbDataAdapter("SELECT * FROM CustomeOrder where [CustomerName] = '" & myCustomerName & "' and [DateOrdered] = '" & DateOrdered & "'  ", con)
            adp.Fill(dt2)
            Me.adp.Update(dt2)
            Me.BindingContext(dt2).EndCurrentEdit()
            adp.Fill(ds2)
            Dim counter As Integer = 0
            con.Close()
            MyRichTextBoxEx1.SelectedText = "DETAILS OF ORDER" & vbCr
            MyRichTextBoxEx1.SelectedText = "__________________________________________________" & vbCr

            For Each Row As DataRow In ds2.Tables(0).Rows
                MyRichTextBoxEx1.SelectedText = (dt2.Rows(counter)(UCase("Recipeordered"))) & vbCr
                Dim RecAmount, RecCost As Decimal
                RecAmount = CDec(dt2.Rows(counter)(UCase("AmountOrdered")))
                RecCost = CDec(dt2.Rows(counter)(UCase("Cost")))
                MyRichTextBoxEx1.SelectedText = vbTab & RecAmount & " x " & RecCost.ToString("C") & " = " & (RecAmount * RecCost).ToString("C") & vbCr
                ' MyRichTextBoxEx1.SelectedText = vbCr
                counter = counter + 1
                TotalCost = (RecAmount * RecCost) + TotalCost
            Next
            MyRichTextBoxEx1.SelectedText = "__________________________________________________" & vbCr
            MyRichTextBoxEx1.SelectedText = vbCr & vbTab & "TOTAL COST  : " & TotalCost.ToString("C") & vbCr
            ' MyRichTextBoxEx1.SelectedText = vbCr & vbTab & "VAT         : " & (TotalCost * 14).ToString("C") & vbCr
            'MyRichTextBoxEx1.SelectedText = vbCr & vbTab & "FINAL AMOUNT: " & (TotalCost + ((TotalCost * 14))).ToString("C") & vbCr
            MyRichTextBoxEx1.SelectedText = "__________________________________________________" & vbCr
            MyRichTextBoxEx1.SelectedText = "Please note: Prices above does not include VAT and delivery costs"
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
        ds2.Dispose()
        dt2.Dispose()
        dt.Dispose()
        adp.Dispose()
    End Sub

    Public Sub AddImage()
        Dim Img As Image
        CustomPicture = My.Computer.FileSystem.FileExists(Application.StartupPath & "\MyLogo.bmp")
        If CustomPicture = True Then
            Img = Image.FromFile(Application.StartupPath & "\MyLogo.bmp")
        Else
            Img = My.Resources.Joey_Logo_JPG
        End If
        Clipboard.SetImage(Img)
        Me.MyRichTextBoxEx1.Paste()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Dispose()
        Me.Close()
    End Sub
End Class