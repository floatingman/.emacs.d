﻿Module Recipe
    Public IngeName As String
    Public IngeVendor As String
    Public IngeUnit As String
    Public IngreMeasure As Decimal
    Public IngrePrice As Decimal

    Public Function RoundToValue(ByVal nValue As Integer, ByVal nCeiling As Double, Optional ByVal RoundUp As Boolean = True) As Double
        Dim tmp As Integer
        Dim tmpVal
        If Not IsNumeric(nValue) Then Exit Function
        nValue = CDbl(nValue)
        tmpVal = ((nValue / nCeiling) + (-0.5 + (RoundUp And 1)))
        tmp = Fix(tmpVal)
        tmpVal = CInt((tmpVal - tmp) * 10 ^ 0)
        nValue = tmp + tmpVal / 10 ^ 0
        'Multiply by ceiling value to set RoundtoValue
        RoundToValue = nValue * nCeiling
    End Function
End Module
