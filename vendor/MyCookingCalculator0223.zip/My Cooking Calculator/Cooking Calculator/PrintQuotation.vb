﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Drawing
Imports System.Math
Imports Microsoft.VisualBasic
Imports System.Windows.Forms
Imports System.Collections
Imports System.Windows.Forms.Form
Public Class PrintQuotation
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(str)
    Public adp As OleDbDataAdapter
    Public ds As New DataSet
    Public dt As New DataTable
    Public RecipeName As String = ""
    Public cmd As OleDbCommand
    Public DateSelected As Boolean = False
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Dispose()
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        btnCreateInvioce.Enabled = True
        MyRichTextBoxEx1.Clear()
        AddImage()
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 12, FontStyle.Underline))
        MyRichTextBoxEx1.SelectedText = vbCr & "COOKING CALCULATOR : QUOTATION" & vbCr & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Customer Name   : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = txtCustomerName.Text & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Delivery Date      : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = MonthCalendar1.SelectionStart.ToShortDateString & vbCr

        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Delivery Adress   : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = txtDeliveryAdress.Text & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "  :" & TextBox1.Text & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "  :" & TextBox2.Text & vbCr & vbCr
        Dim aa As Integer = 1
        Dim total As Decimal = 0
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "--- RECIPES SELECTED FOR QUOTATION ---" & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Underline)
        MyRichTextBoxEx1.SelectedText = "Recipe name :".PadRight(19, " ") & vbTab & "#Ord x  Pr/Rec   =  Sub total " & vbCr
        For Each Check In Form1.CheckedListBox1.CheckedItems
            Dim MyIndex As Integer = Form1.CheckedListBox1.Items.IndexOf(Check)
            MyRichTextBoxEx1.SelectedText = aa & ":  " & (Check.ToString().PadRight(35, " : ")) & vbCr
            ' MyRichTextBoxEx1.SelectedText = vbTab & vbTab & Form1.RecipeAmountOrdered(MyIndex) & "     x     " & (Form1.RecipeTotal(MyIndex) + Form1.RecipePrepCost(MyIndex) + Form1.RecipeDecorations(MyIndex)).ToString("C") & " = " & (Form1.RecipeAmountOrdered(MyIndex) * Form1.RecipeTotal(MyIndex)).ToString("C") & vbCr
            MyRichTextBoxEx1.SelectedText = vbTab & vbTab & Form1.RecipeAmountOrdered(MyIndex) & "     x     " & (Form1.RecipeTotal(MyIndex)).ToString("C") & " = " & (Form1.RecipeAmountOrdered(MyIndex) * Form1.RecipeTotal(MyIndex)).ToString("C") & vbCr
            total = total + (Form1.RecipeTotal(MyIndex) * Form1.RecipeAmountOrdered(MyIndex))
            aa = aa + 1
        Next
        MyRichTextBoxEx1.SelectedText = "___________________________________________________________" & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbCr & vbTab & vbTab & "---Sub Total     : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & total.ToString("C") & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "---Delivery cost : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & Form1.RecipeDeliveryCost(0).ToString("C") & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "---TOTAL PRICE   : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & (total + Form1.RecipeDeliveryCost(0)).ToString("C")
        MyRichTextBoxEx1.SelectedText = vbCr & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = "I (Full names)________________________________________  " & vbCr & "hereby accept the above quotation in its total."
        MyRichTextBoxEx1.SelectedText = vbCr & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = "Customer Signature:  _________________________________________     on :" & Now().ToShortDateString & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectedText = "__________________________________________________________________________" & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Tjeks to    ".PadRight(20, " ") & vbTab & " : " & strOwnerName.PadRight(35, " ") & vbTab & strTelephone & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Bank Name   ".PadRight(20, " ") & vbTab & " : " & strBankName.PadRight(35, " ") & vbTab & strAdress1 & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Branch Code ".PadRight(20, " ") & vbTab & " : " & strBranchNum.PadRight(35, " ") & vbTab & strAdress2 & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Type Account".PadRight(20, " ") & vbTab & " : " & strTypeAccount.PadRight(35, " ") & vbTab & strAdress3 & "   " & strPostalCode & vbCr
        MyRichTextBoxEx1.SelectedText = "________________________________________________________________________"
        Button1.Enabled = False
    End Sub

    Private Sub PrintQuotation_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Dispose()
        Me.Close()
    End Sub

    Private Sub PrintQuotation_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MonthCalendar1.SelectionStart = Now
        Button1.Enabled = True
        btnCreateInvioce.Enabled = False
        Dim dt As DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        txtCustomerName.Items.Clear()
        MyRichTextBoxEx1.Clear()
        dt = New DataTable
        adp = New OleDbDataAdapter("select  * from Customer ", con)
        adp.Fill(dt)
        Me.adp.Update(dt)
        Me.BindingContext(dt).EndCurrentEdit()
        Dim SqlStr As String
        SqlStr = "select  * from Customer "
        cmd = New OleDbCommand(SqlStr, con)
        cmd.ExecuteNonQuery()
        adp.Fill(ds)
        Dim counter As Integer = 0
        For Each Row As DataRow In ds.Tables(0).Rows
            Dim Recipe(2) As String
            Me.txtCustomerName.Items.Add(dt.Rows(counter)(UCase("CustomerName")))
            counter = counter + 1
        Next
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        MyRichTextBoxEx1.Clear()
        MyRichTextBoxEx1.Clear()
    End Sub

    Private Sub PRINTQUOTATIONToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PRINTQUOTATIONToolStripMenuItem.Click
        If MyRichTextBoxEx1.Lines.Count < 2 Then
            MsgBox("RichTextbox is Empty, nothing to print", MsgBoxStyle.OkOnly, "Nothing to Print")
            Exit Sub
        End If
        MyRichTextBoxEx1.PrintRichTextContents()
    End Sub

    Private Sub SAVEQUOTATIONTOFILEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SAVEQUOTATIONTOFILEToolStripMenuItem.Click
        If MyRichTextBoxEx1.Lines.Count < 2 Then
            MsgBox("RichTextbox is Empty, nothing to Save", MsgBoxStyle.OkOnly, "Nothing to Save")
            Exit Sub
        End If
        Dim folderExists As Boolean
        Dim savePath As String = ""

        folderExists = My.Computer.FileSystem.DirectoryExists("C:\My Recipes files")
        If Not folderExists Then
            My.Computer.FileSystem.CreateDirectory("C:\My Recipes files\Quotations")
        End If
        With SaveFile
            .AddExtension = True
            .Title = "Save the Quations as a Quotation File!"
            .Filter = "Quotation files (.rtf)|*.rtf"
            .InitialDirectory = "C:\My Recipes files\Quotations\"
            .ShowDialog()
            savePath = .FileName
        End With
        Try
            MyRichTextBoxEx1.SaveFile(savePath)
        Catch ex As Exception
            MsgBox("There was a error saving the file...", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
        MyRichTextBoxEx1.Rtf = ""
        folderExists = My.Computer.FileSystem.DirectoryExists("C:\My Recipes files\Quotations")
        If Not folderExists Then
            My.Computer.FileSystem.CreateDirectory("C:\My Recipes files\Quotations")
        End If
        Try
            With OpenFileDialog1
                .AddExtension = True
                .Title = "Open the Quotions as a Quotation File!"
                .Filter = "Quotation files (.rtf)|*.rtf"
                .InitialDirectory = "C:\My Recipes files\Quotations\"
                .ShowDialog()
                savePath = .FileName
            End With
            MyRichTextBoxEx1.LoadFile(OpenFileDialog1.FileName)
        Catch ex As Exception
            MsgBox("File was not opened..", MsgBoxStyle.Information)
        End Try

    End Sub

    Public Sub AddImage()
        Dim Img As Image
        CustomPicture = My.Computer.FileSystem.FileExists(Application.StartupPath & "\MyLogo.bmp")
        If CustomPicture = True Then
            Img = Image.FromFile(Application.StartupPath & "\MyLogo.bmp")
        Else
            Img = My.Resources.Joey_Logo_JPG
        End If
        Clipboard.SetImage(Img)
        Me.MyRichTextBoxEx1.Paste()
    End Sub

    Private Sub txtCustomerName_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCustomerName.SelectedValueChanged
        Dim dt As New DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim RecipeName As String = ""
        CustomerName = txtCustomerName.SelectedItem.ToString
        adp2 = New OleDbDataAdapter("SELECT * FROM Customer where CustomerName = '" & CustomerName & "' ", con)
        adp2.fill(dt)
        txtDeliveryAdress.Text = dt.Rows(0)("Adress1")
        TextBox1.Text = dt.Rows(0)("Adress2")
        TextBox2.Text = dt.Rows(0)("Adress3")
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
    End Sub

    Private Sub btnClearQuote_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearQuote.Click
        MyRichTextBoxEx1.Clear()
    End Sub

    Private Sub btnCreateInvioce_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreateInvioce.Click
        btnCreateInvioce.Enabled = False
        MyRichTextBoxEx1.Clear()
        AddImage()
        MyRichTextBoxEx1.SelectionFont = (New Font("Arial", 12, FontStyle.Underline))
        MyRichTextBoxEx1.SelectedText = vbCr & " COOKING CALCULATOR INVOICE " & vbCr & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Customer Name   : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = txtCustomerName.Text & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Delivery Date   : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = MonthCalendar1.SelectionStart.ToShortDateString & vbCr

        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "Delivery Adress : "
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Regular)
        MyRichTextBoxEx1.SelectedText = txtDeliveryAdress.Text & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "  " & TextBox1.Text & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "  " & TextBox2.Text & vbCr & vbCr

        Dim aa As Integer = 1
        Dim total As Decimal = 0

        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = "--- RECIPES SELECTED FOR INVOICE ---" & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Underline)

        MyRichTextBoxEx1.SelectedText = "Recipe name : ".PadRight(19, " ") & vbTab & "#Ord x  Pr/Rec   =  Sub total " & vbCr
        For Each Check In Form1.CheckedListBox1.CheckedItems
            Dim MyIndex As Integer = Form1.CheckedListBox1.Items.IndexOf(Check)

            MyRichTextBoxEx1.SelectedText = aa & ":  " & (Check.ToString().PadRight(35, " : ")) & vbCr
            MyRichTextBoxEx1.SelectedText = vbTab & vbTab & Form1.RecipeAmountOrdered(MyIndex) & "     x     " & (Form1.RecipeTotal(MyIndex) * Form1.RecipeAmountOrdered(MyIndex)).ToString("C") & " = " & (Form1.RecipeAmountOrdered(MyIndex) * Form1.RecipeTotal(MyIndex)).ToString("C") & vbCr
            total = total + (Form1.RecipeTotal(MyIndex) * Form1.RecipeAmountOrdered(MyIndex))
            aa = aa + 1
        Next
        MyRichTextBoxEx1.SelectedText = "___________________________________________________________" & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbCr & vbTab & vbTab & "---Sub Total     : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & total.ToString("C") & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "---Delivery cost : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & Form1.RecipeDeliveryCost(0).ToString("C") & vbCr
        MyRichTextBoxEx1.SelectionFont = New Font(MyRichTextBoxEx1.SelectionFont, FontStyle.Bold)
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & "---TOTAL PRICE   : ".PadRight(25, " ")
        MyRichTextBoxEx1.SelectedText = vbTab & vbTab & (total + Form1.RecipeDeliveryCost(0)).ToString("C")
        MyRichTextBoxEx1.SelectedText = vbCr & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = "I (Full names)________________________________________  " & vbCr & "hereby accept the above invoice in its total."
        MyRichTextBoxEx1.SelectedText = vbCr & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = "Customer Signature:  _________________________________________     on :" & Now().ToShortDateString & vbCr & vbCr
        MyRichTextBoxEx1.SelectedText = vbCr
        MyRichTextBoxEx1.SelectedText = "__________________________________________________________________________" & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Tjeks to    ".PadRight(20, " ") & vbTab & " : " & strOwnerName.PadRight(35, " ") & vbTab & strTelephone & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Bank Name   ".PadRight(20, " ") & vbTab & " : " & strBankName.PadRight(35, " ") & vbTab & strAdress1 & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Branch Code ".PadRight(20, " ") & vbTab & " : " & strBranchNum.PadRight(35, " ") & vbTab & strAdress2 & vbCr
        MyRichTextBoxEx1.SelectedText = vbTab & "Type Account".PadRight(20, " ") & vbTab & " : " & strTypeAccount.PadRight(35, " ") & vbTab & strAdress3 & "   " & strPostalCode & vbCr
        MyRichTextBoxEx1.SelectedText = "________________________________________________________________________"
        AddInvoiceToTable()
    End Sub
    Public Sub AddInvoiceToTable()
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        dt = New DataTable
        Try
            For Each Check In Form1.CheckedListBox1.CheckedItems
                Dim MyIndex As Integer = Form1.CheckedListBox1.Items.IndexOf(Check)
                Dim RecipAmount, Reciptotal As Decimal
                Dim RecipeName As String = Check.ToString()
                Dim CustomerName As String = txtCustomerName.Text
                Dim DateOrd As String = (MonthCalendar1.SelectionStart.ToShortDateString).ToString
                RecipAmount = Form1.RecipeAmountOrdered(MyIndex)
                Reciptotal = Form1.RecipeTotal(MyIndex)

                adp = New OleDbDataAdapter("insert into CustomeOrder values('" & RecipeName & "' , " & RecipAmount & " , '" & DateOrd & "' ," & Reciptotal & ",'" & CustomerName & "' )", con)
                adp.Fill(dt)
                Me.BindingContext(dt).EndCurrentEdit()
                Me.adp.Update(dt)
                Me.BindingContext(dt).Position = 1
            Next
        Catch ex As Exception

        End Try
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
    End Sub

    Private Sub MonthCalendar1_DateSelected(ByVal sender As Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateSelected
        If MonthCalendar1.SelectionStart.ToShortDateString < Now.ToShortDateString Then
            MsgBox("This date is wrong, before the current date. Please select another date.", MsgBoxStyle.Exclamation, "WARNING DATE TO OLD")
        End If
    End Sub
End Class
