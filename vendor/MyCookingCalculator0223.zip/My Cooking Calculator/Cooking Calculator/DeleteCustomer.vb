﻿
Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Imports System.Windows.Forms
Public Class DeleteCustomer
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(Str)
    Public adp As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public ds As New DataSet
    Public dt As New DataTable
    Public Oldname As String = ""
    Private Sub ListBox1_SelectedValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedValueChanged
        Dim dt As New DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        Dim RecipeName As String = ""
        CustomerName = ListBox1.SelectedItem.ToString
        adp = New OleDbDataAdapter("SELECT * FROM Customer where CustomerName = '" & CustomerName & "' ", con)
        adp.Fill(dt)
        txtCustomerName.Text = dt.Rows(0)("CustomerName")
        txtAdress1.Text = dt.Rows(0)("Adress1")
        txtAdress2.Text = dt.Rows(0)("Adress2")
        txtAdress3.Text = dt.Rows(0)("Adress3")
        txtTelephone.Text = dt.Rows(0)("Telephone")
        txtEMail.Text = dt.Rows(0)("Email")
        txtCompanyName.Text = dt.Rows(0)("CompanyName")
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        dt.Dispose()
        Oldname = txtCustomerName.Text
    End Sub

    Private Sub btnDeleteCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeleteCustomer.Click
        Dim Responce As Integer
        Responce = MessageBox.Show("Are you sure you want to delete this record ?", "W A R N I N G..", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2)
        Dim strSQL As String
        Dim cmd As OleDbCommand
        If Responce = vbYes Then
            If con.State = ConnectionState.Closed Then
                con.Open()
            End If
            strSQL = "DELETE  FROM Customer  WHERE [CustomerName] = '" & ListBox1.SelectedItem.ToString & "'  "
            cmd = New OleDbCommand(strSQL, con)
            cmd.ExecuteNonQuery()
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            RefreshScreen()
        End If
    End Sub

    Sub RefreshScreen()
        Dim dt As DataTable
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        ListBox1.Items.Clear()
        Try
            dt = New DataTable
            adp = New OleDbDataAdapter("select  * from Customer ", con)
            adp.Fill(dt)
            Me.adp.Update(dt)
            Me.BindingContext(dt).EndCurrentEdit()
            Dim SqlStr As String
            SqlStr = "select  * from Customer "
            cmd = New OleDbCommand(SqlStr, con)
            cmd.ExecuteNonQuery()
            adp.Fill(ds)
            Dim counter As Integer = 0
            For Each Row As DataRow In ds.Tables(0).Rows
                Me.ListBox1.Items.Add(dt.Rows(counter)(UCase("CustomerName")))
                counter = counter + 1
            Next
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        Catch ex As Exception
            ' MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub DeleteCustomer_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dispose()
        Me.Close()
    End Sub

    Private Sub DeleteCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshScreen()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Dispose()
        Me.Close()
    End Sub
End Class