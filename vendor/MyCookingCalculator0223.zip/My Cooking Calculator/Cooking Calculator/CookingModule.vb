﻿Imports System.IO
Imports System.Drawing.Drawing2D
Imports System.Drawing
Imports System.Data.OleDb
Imports System.Data

Module CookingModule
    Dim Rs_AppPath As String = System.IO.Directory.GetCurrentDirectory
    Public testname1, testname2, testname3, testname4, testname5, testname6, testname7, testname8, testname9, testname10 As String
    Public AmountTests As Integer
    'Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath.Substring(0, Application.StartupPath.LastIndexOf("bin")) & "libra.mdb;Mode=Share Deny None;Extended Properties=;Jet OLEDB:System database=;Jet OLEDB:Registry Path=;Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False"
    Public currentstudent As String
    Public lecturerdays1, lecturerdays2, lecturerdays3, lecturerdays4 As Integer
    Public ISprint As Boolean = False
    Public lECTURER, cLASSrOOM, sCHOOL As String
    Public decAAFixFactor, decCarFuelFactor, decServiceRepairCost, decTyreCostFactor, decPetrolPrice, decCostPerKilometer As Decimal
    Public strAccountNum, strAdress1, strAdress2, strAdress3, strBranchNum, strOwnerName, strPostalCode, strTelephone, strTypeAccount, strBankName As String

    Public Class iCam
#Region "Api/constants"

        Private Const WS_CHILD As Integer = &H40000000
        Private Const WS_VISIBLE As Integer = &H10000000
        Private Const SWP_NOMOVE As Short = &H2S
        Private Const SWP_NOZORDER As Short = &H4S
        Private Const WM_USER As Short = &H400S
        Private Const WM_CAP_DRIVER_CONNECT As Integer = WM_USER + 10
        Private Const WM_CAP_DRIVER_DISCONNECT As Integer = WM_USER + 11
        Private Const WM_CAP_SET_VIDEOFORMAT As Integer = WM_USER + 45
        Private Const WM_CAP_SET_PREVIEW As Integer = WM_USER + 50
        Private Const WM_CAP_SET_PREVIEWRATE As Integer = WM_USER + 52
        Private Const WM_CAP_GET_FRAME As Long = 1084
        Private Const WM_CAP_COPY As Long = 1054
        Private Const WM_CAP_START As Long = WM_USER
        Private Const WM_CAP_STOP As Long = (WM_CAP_START + 68)
        Private Const WM_CAP_SEQUENCE As Long = (WM_CAP_START + 62)
        Private Const WM_CAP_SET_SEQUENCE_SETUP As Long = (WM_CAP_START + 64)
        Private Const WM_CAP_FILE_SET_CAPTURE_FILEA As Long = (WM_CAP_START + 20)

        Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Short, ByVal lParam As String) As Integer
        Private Declare Function capCreateCaptureWindowA Lib "avicap32.dll" (ByVal lpszWindowName As String, ByVal dwStyle As Integer, ByVal x As Integer, ByVal y As Integer, ByVal nWidth As Integer, ByVal nHeight As Short, ByVal hWndParent As Integer, ByVal nID As Integer) As Integer
        Private Declare Function capGetDriverDescriptionA Lib "avicap32.dll" (ByVal wDriver As Short, ByVal lpszName As String, ByVal cbName As Integer, ByVal lpszVer As String, ByVal cbVer As Integer) As Boolean
        Private Declare Function BitBlt Lib "GDI32.DLL" (ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As Int32) As Boolean

#End Region
        Private iDevice As String
        Private hHwnd As Integer
        Private lwndC As Integer
        Public iRunning As Boolean
        Private CamFrameRate As Integer = 15
        Private OutputHeight As Integer = 240
        Private OutputWidth As Integer = 360





















        Public Sub resetCam()
            'resets the camera after setting change
            If iRunning Then
                closeCam()
                Application.DoEvents()
                If setCam() = False Then
                    MessageBox.Show("Errror Setting/Re-Setting Camera")
                End If
            End If
        End Sub

        Public Sub initCam(ByVal parentH As Integer)
            'Gets the handle and initiates camera setup
            If Me.iRunning = True Then
                MessageBox.Show("Camera Is Already Running")
                Exit Sub
            Else
                hHwnd = capCreateCaptureWindowA(iDevice, WS_VISIBLE Or WS_CHILD, 0, 0, OutputWidth, CShort(OutputHeight), parentH, 0)
                If setCam() = False Then
                    MessageBox.Show("Error setting Up Camera")
                End If
            End If
        End Sub

        Public Sub setFrameRate(ByVal iRate As Long)
            'sets the frame rate of the camera
            CamFrameRate = CInt(1000 / iRate)
            resetCam()
        End Sub

        Private Function setCam() As Boolean
            'Sets all the camera up
            If SendMessage(hHwnd, WM_CAP_DRIVER_CONNECT, CShort(iDevice), CType(0, String)) = 1 Then
                SendMessage(hHwnd, WM_CAP_SET_PREVIEWRATE, CShort(CamFrameRate), CType(0, String))
                SendMessage(hHwnd, WM_CAP_SET_PREVIEW, 1, CType(0, String))
                Me.iRunning = True
                Return True
            Else
                Me.iRunning = False
                Return False
            End If
        End Function

        Public Function closeCam() As Boolean
            'Closes the camera
            If Me.iRunning Then
                closeCam = CBool(SendMessage(hHwnd, WM_CAP_DRIVER_DISCONNECT, 0, CType(0, String)))
                Me.iRunning = False
            End If
        End Function

        Public Function copyFrame(ByVal src As PictureBox, ByVal rect As RectangleF) As Bitmap
            If iRunning Then
                Dim srcPic As Graphics = src.CreateGraphics
                Dim srcBmp As New Bitmap(src.Width, src.Height, srcPic)
                Dim srcMem As Graphics = Graphics.FromImage(srcBmp)
                Dim HDC1 As IntPtr = srcPic.GetHdc
                Dim HDC2 As IntPtr = srcMem.GetHdc
                BitBlt(HDC2, 0, 0, CInt(rect.Width), _
                  CInt(rect.Height), HDC1, CInt(rect.X), CInt(rect.Y), 13369376)
                copyFrame = CType(srcBmp.Clone(), Bitmap)
                'Clean Up 
                srcPic.ReleaseHdc(HDC1)
                srcMem.ReleaseHdc(HDC2)
                srcPic.Dispose()
                srcMem.Dispose()
            Else
                MessageBox.Show("Camera Is Not Running!")
            End If

        End Function

        Public Function FPS() As Integer
            Return CInt(1000 / (CamFrameRate))
        End Function
    End Class
    Public Class FrmImage
        Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
        Public Sub New()
            MyBase.New()
            'This call is required by the Windows Form Designer.
            InitializeComponent()
            'Add any initialization after the InitializeComponent() call
        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer
        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents picImage As System.Windows.Forms.PictureBox
        Friend WithEvents SBar As System.Windows.Forms.Label
        Friend WithEvents cmdSave As System.Windows.Forms.Button
        Friend WithEvents SaveFile As System.Windows.Forms.SaveFileDialog
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.picImage = New System.Windows.Forms.PictureBox
            Me.SBar = New System.Windows.Forms.Label
            Me.cmdSave = New System.Windows.Forms.Button
            Me.SaveFile = New System.Windows.Forms.SaveFileDialog
            Me.SuspendLayout()
            '
            'picImage
            '
            Me.picImage.BackColor = System.Drawing.Color.Black
            Me.picImage.Location = New System.Drawing.Point(8, 8)
            Me.picImage.Name = "picImage"
            Me.picImage.Size = New System.Drawing.Size(344, 240)
            Me.picImage.TabIndex = 1
            Me.picImage.TabStop = False
            '
            'SBar
            '
            Me.SBar.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.SBar.Location = New System.Drawing.Point(8, 256)
            Me.SBar.Name = "SBar"
            Me.SBar.Size = New System.Drawing.Size(344, 32)
            Me.SBar.TabIndex = 2
            Me.SBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            '
            'cmdSave
            '
            Me.cmdSave.Location = New System.Drawing.Point(80, 296)
            Me.cmdSave.Name = "cmdSave"
            Me.cmdSave.Size = New System.Drawing.Size(200, 24)
            Me.cmdSave.TabIndex = 3
            Me.cmdSave.Text = "Save Image"
            '
            'FrmImage
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(360, 326)
            Me.Controls.Add(Me.cmdSave)
            Me.Controls.Add(Me.SBar)
            Me.Controls.Add(Me.picImage)
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "FrmImage"
            Me.Text = "Capture Still Image"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private Sub FrmImage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            SBar.Text = ("Image Taken At - " & TimeString & " , On the - " & DateString)
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            Dim savePath As String
            With SaveFile
                .Title = "Save Image File!"
                .Filter = "BitMap files only (.bmp)|*.bmp"
                .InitialDirectory = "c:\"
                .ShowDialog()
                savePath = .FileName
            End With
            picImage.Image.Save(savePath)
        End Sub
    End Class

    Function SubJectAbreviation(ByVal SubjectName As String) As String
        s = SubjectName
        ' Split string based on spaces
        Dim words As String() = s.Split(New Char() {" "c})
        ' Use For Each loop over words and display them
        Dim word As String
        Dim SUBJECTNAME2 As String = ""
        For Each word In words
            If word <> UCase("TO") And word <> UCase("OF") And word <> UCase("&") And word <> UCase("AND") And word <> UCase("IN") Then
                finalword = UCase(word.Substring(0, 1))
                SUBJECTNAME2 = SUBJECTNAME2 & finalword
            End If
        Next
        Return SUBJECTNAME2
    End Function

    Function DoesTableExist(ByVal tblName As String, ByVal cnnStr As String) As Boolean
        ' Use to Check if a Database does Exsist
        Dim dbConn As New OleDbConnection(cnnStr)
        dbConn.Open()
        Dim restrictions(3) As String
        restrictions(2) = tblName
        Dim dbTbl As DataTable = dbConn.GetSchema("Tables", restrictions)
        If dbTbl.Rows.Count = 0 Then
            'Table does not exist
            DoesTableExist = False
        Else
            'Table exists
            DoesTableExist = True
        End If
        dbTbl.Dispose()
        dbConn.Close()
        dbConn.Dispose()
    End Function

    Function DoesFieldExist(ByVal tblName As String, ByVal fldName As String, ByVal cnnStr As String) As Boolean
        ' Use to Check if Field does exsist
        Dim dbConn As New OleDbConnection(cnnStr)
        dbConn.Open()
        Dim dbTbl As New DataTable
        ' Get the table definition loaded in a table adapter
        Dim strSql As String = "Select TOP 1 * from " & tblName
        Dim dbAdapater As New OleDbDataAdapter(strSql, dbConn)
        dbAdapater.Fill(dbTbl)
        ' Get the index of the field name
        Dim i As Integer = dbTbl.Columns.IndexOf(fldName)
        If i = -1 Then
            'Field is missing
            DoesFieldExist = False
        Else
            'Field is there
            DoesFieldExist = True
        End If
        dbTbl.Dispose()
        dbConn.Close()
        dbConn.Dispose()
    End Function

    

End Module
