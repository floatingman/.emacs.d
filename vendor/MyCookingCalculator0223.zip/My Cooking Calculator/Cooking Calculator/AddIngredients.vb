﻿Public Class AddIngredients
    Public Cancel As Boolean = False
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If Not IsNumeric(txtPriceItem.Text) Then
            txtPriceItem.Focus()
            txtPriceItem.BackColor = Color.LightPink
            txtPriceItem.Text = ""
            Cancel = False
            Exit Sub
        End If
        If Not IsNumeric(txtMeasure.Text) Then
            txtMeasure.Focus()
            txtMeasure.BackColor = Color.LightPink
            txtMeasure.Text = ""
            Exit Sub
        End If
        If CDec(txtMeasure.Text) = 0 And CDec(txtPriceItem.Text) = 0 Then
            MsgBox("You can not have both Measure and Weight as 0, please check and correct", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        Cancel = False
        Me.Close()
    End Sub

    Private Sub AddIngredients_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim X As Integer = Form1.MousePosition.X - 300
        Dim y As Integer = Form1.MousePosition.Y - 300
        Me.DesktopLocation = New Point(X, y)
        txtVendorName.Text = txtVendorName.Items(0)
        cmbUnit.Text = cmbUnit.Items(0)
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Cancel = True
        Me.Close()
    End Sub

    Private Sub txtPriceItem_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPriceItem.Validating
        If txtPriceItem.Text = "" Then
            txtPriceItem.Text = 0
        End If
        If Not IsNumeric(txtPriceItem.Text) Then
            txtPriceItem.Text = 0
        End If
    End Sub

    Private Sub txtMeasure_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMeasure.TextChanged
        If txtMeasure.Text = "" Then
            txtMeasure.Text = 0
        End If
        If Not IsNumeric(txtMeasure.Text) Then
            txtMeasure.Text = 0
        End If
    End Sub
End Class