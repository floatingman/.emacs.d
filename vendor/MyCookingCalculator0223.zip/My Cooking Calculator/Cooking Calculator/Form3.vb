﻿Imports System.IO
Imports Microsoft.VisualBasic.FileIO
Public Class Form3
    Public objStreamReader As StreamReader
    Public StrUserName As String
    Public StrPassword As String
    Public COUNTER As Integer = 0

    Private Sub Form3_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Not (TextBox1.Text = StrUserName And TextBox2.Text = StrPassword) Then
            End
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Location = New Point((Screen.PrimaryScreen.Bounds.Width - Me.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - Me.Height) / 2)
        Timer1.Enabled = True
        objStreamReader = New StreamReader(Application.StartupPath & "\Username.txt")
        StrUserName = objStreamReader.ReadLine
        StrPassword = objStreamReader.ReadLine
        objStreamReader.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        COUNTER = COUNTER + 1
        If TextBox1.Text = StrUserName And TextBox2.Text = StrPassword Then
            Form1.Enabled = True
            Me.Close()
            GroupBox1.Enabled = True
        Else
            MsgBox("NOT YET, THAT WAS TRY NUMBER " & COUNTER & " YOU HAVE " & 3 - COUNTER & " LEFT")
            If COUNTER = 3 Then
                End
            End If
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If SplashScreen1.Visible = True Then
            SplashScreen1.Close()
            Timer1.Enabled = False
        End If
    End Sub
End Class