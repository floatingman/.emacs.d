﻿Imports System.Data.OleDb
Imports System.Data
Imports System.IO
Public Class AddRecipes
    Public str As String = "Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=" & Application.StartupPath & "\Recipes.mdb"
    Public con As New OleDbConnection(str)
    Public adp, adp2 As OleDbDataAdapter
    Public cmd As OleDbCommand
    Public cmd2 As OleDbCommand
    Public ds1 As New DataSet
    Public dt As New DataTable
    Dim ds As New DataSet
    Public RecipeSteps As String

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        Me.Close()
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton5.Click
        If SplitContainer1.Visible = True Then
            ExitToolStripMenuItem.PerformClick()
            If DataGridView1.IsCurrentCellDirty Then
                DataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit)
            End If
            SplitContainer1.Visible = False
        End If
        Dim MyBackColor As Color = txtRecipeName.BackColor
        ToolStripStatusLabel1.Text = ""
        txtRecipeName.BackColor = MyBackColor
        If txtRecipeName.Text = "" Then
            ToolStripStatusLabel1.Text = "You need to Enter a name for the Recipe"
            txtRecipeName.Focus()
            txtRecipeName.BackColor = Color.LightPink
            Exit Sub
        Else
            txtRecipeName.BackColor = MyBackColor
        End If
        If ListView1.Items.Count < 1 Then
            If SplitContainer1.Visible = True Then
                SplitContainer1.Visible = False
            End If
            Beep()
            ToolStripStatusLabel1.Text = "You need to Enter at least ONE INGREDIENT for the Recipe"
            Exit Sub
        End If
        If DataGridView1.Rows.Count = 1 Then
            ToolStripStatusLabel1.Text = "Your recipe should have some Steps"
            DataGridView1.Focus()
            ToolStripButton6.PerformClick()
            Beep()
            Exit Sub
        End If
        If Not IsNumeric(txtTime.Text) Then
            txtTime.Clear()
            txtTime.Focus()
            txtTime.BackColor = Color.LightPink
            Beep()
            Exit Sub
        End If
        If Not IsNumeric(txtTemp.Text) Then
            txtTemp.Clear()
            txtTemp.Focus()
            txtTemp.BackColor = Color.LightPink
            Beep()
            Exit Sub
        End If
        If Not IsNumeric(txtServes.Text) Then
            txtServes.Clear()
            txtServes.Focus()
            txtServes.BackColor = Color.LightPink
            Exit Sub
        End If
        txtServes.BackColor = MyBackColor
        txtTemp.BackColor = MyBackColor
        txtTime.BackColor = MyBackColor
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
        dt = New DataTable
        Dim SqlStr As String
        Try

            SqlStr = "insert into Recipe1 values('" & txtRecipeName.Text & "','" & cmbCategory.Text & "' , " & CDec(txtTime.Text) & ",'" & RecipeSteps & "','" & txtRecipeBy.Text & "', '" & cmbMainIngre.Text & "' ,'" & cmbCuzineStyle.Text & "' ," & CDec(txtServes.Text) & " ," & CDec(txtTemp.Text) & "  )"
            '  cmd = New OleDbCommand(SqlStr, con)
            adp = New OleDbDataAdapter("insert into Recipe1 values('" & txtRecipeName.Text & "','" & cmbCategory.Text & "' , " & CDec(txtTime.Text) & ",'" & RecipeSteps & "','" & txtRecipeBy.Text & "', '" & cmbMainIngre.Text & "' ,'" & cmbCuzineStyle.Text & "' ," & CDec(txtServes.Text) & " ," & CDec(txtTemp.Text) & ",'" & CDec(txtPrepTime.Text) & "','" & cmbServeType.Text & "', '" & txtBook.Text & "'   )", con)
            adp.Fill(dt)
            ' cmd.ExecuteNonQuery()
            Me.BindingContext(dt).EndCurrentEdit()
            Me.adp.Update(dt)
            Me.BindingContext(dt).Position = 1

        Catch ex As Exception
            ' Dislay Message if error occur
            ToolStripStatusLabel1.Text = "You have an ERROR, Check that the Recipe Name is not Duplicated ....  "
            Beep()
            Exit Sub
        End Try

        '''''''''''''''''''''''''''''''
        '' Now the ingredient table
        '''''''''''''''''''''''''''''''''''''''''

        Try
            For b = 0 To ListView1.Items.Count - 1
                '  Dim SqlStr2 As String
                ' Dim cmd2 As OleDbCommand
                Dim Recipename As String = txtRecipeName.Text
                Dim Ingrename As String = ListView1.Items(b).SubItems(0).Text
                Dim Prepcomment As String = ListView1.Items(b).SubItems(1).Text
                Dim IngreWeight As Decimal = CDec(ListView1.Items(b).SubItems(2).Text)
                Dim IngreAmount As Decimal = CDec(ListView1.Items(b).SubItems(3).Text)
                Dim IngreUnit As String = ListView1.Items(b).SubItems(4).Text
                dt2 = New DataTable
                adp2 = New OleDbDataAdapter("insert into Ingredients values('" & txtRecipeName.Text & "','" & Ingrename & "' , '" & Prepcomment & "'," & IngreWeight & "," & IngreAmount & ", '" & IngreUnit & "'  )", con)
                adp2.Fill(dt)
                Me.BindingContext(dt2).EndCurrentEdit()
                Me.adp2.Update(dt2)
                Me.BindingContext(dt2).Position = 1
                ' cmd2 = New OleDbCommand(SqlStr2, con)
                ' cmd2.ExecuteNonQuery()
            Next
            Me.BindingContext("Ingredients").EndCurrentEdit()
            Me.BindingContext("Recipes1").EndCurrentEdit()
        Catch ex As Exception
            ' Dislay Message if error occur
            MsgBox(ex.ToString)
        End Try

        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        ToolStripStatusLabel1.Text = "NEW RECIPE :" & UCase(txtRecipeName.Text) & " WAS ADDED ...CLICK EXIT TO RETURN."
        txtRecipeName.Text = ""
        txtPrepTime.Text = 0
        txtRecipeBy.Text = ""
        txtServes.Text = 0
        txtTemp.Text = 0
        txtTime.Text = 0
        txtBook.Text = ""
        ' DataGridView1.DataSource = ""
        DataGridView1.Rows.Clear()
        ListView1.Items.Clear()

    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        IgredientToRecipe.ShowDialog()

        If IgredientToRecipe.cancel <> True Then
            Dim lv As ListViewItem = ListView1.Items.Add(IgredientToRecipe.cmbIngreName.Text)
            lv.SubItems.Add(IgredientToRecipe.txtPrepComment.Text)
            lv.SubItems.Add(IgredientToRecipe.txtIngeWeight.Text)
            lv.SubItems.Add(IgredientToRecipe.txtIngrAmount.Text)
            lv.SubItems.Add(IgredientToRecipe.cmbMeasureUnit.Text)
        End If
    End Sub

    Private Sub AddRecipes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SplitContainer1.Visible = False
        cmbMainIngre.Items.Clear()
        For a = 0 To Form1.ListView6.Items.Count - 1
            cmbMainIngre.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
        cmbCuzineStyle.Text = cmbCuzineStyle.Items(0)
        cmbMainIngre.Text = cmbMainIngre.Items(0)
        cmbCategory.Text = cmbCategory.Items(0)
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        If ListView1.SelectedItems.Count > 0 AndAlso MessageBox.Show("Do you want to delete this item?", "Confirm", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then 'make sure there is a selected item to delete  
            ListView1.SelectedItems(0).Remove()
        End If
    End Sub

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton6.Click
        SplitContainer1.Visible = True
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        SplitContainer1.Visible = False
        RecipeSteps = ""
        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value <> "" Then
                RecipeSteps = RecipeSteps & (row.Cells(0).Value) & "#"
            End If
        Next
    End Sub
    Public Sub AutoNumberRowsForGridView(ByVal dataGridView As DataGridView)
        If dataGridView IsNot Nothing Then
            Dim count As Integer = 0
            While (count <= (dataGridView.Rows.Count - 2))
                dataGridView.Rows(count).HeaderCell.Value = String.Format((count + 1).ToString(), "0")
                count += 1
            End While
        End If
    End Sub

    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        AutoNumberRowsForGridView(DataGridView1)
    End Sub

    Private Sub txtTemp_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtTemp.Validating
        If txtTemp.Text = "" Then
            txtTemp.Text = 1
        End If
        If Not IsNumeric(txtTemp.Text) Then
            txtTemp.Text = 1
        End If
    End Sub

    Private Sub txtPrepTime_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtPrepTime.Validating
        If txtPrepTime.Text = "" Then
            txtPrepTime.Text = 1
        End If
        If Not IsNumeric(txtPrepTime.Text) Then
            txtPrepTime.Text = 1
        End If
    End Sub

    Private Sub txtTime_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtTime.Validating
        If txtTime.Text = "" Then
            txtTime.Text = 1
        End If
        If Not IsNumeric(txtTime.Text) Then
            txtTime.Text = 1
        End If
    End Sub

    Private Sub txtServes_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtServes.Validating
        If txtServes.Text = "" Then
            txtServes.Text = 1
        End If
        If Not IsNumeric(txtServes.Text) Then
            txtServes.Text = 1
        End If
    End Sub


    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        If ListView1.SelectedItems.Count > 0 Then
            If ListView1.Items.Count > 0 Then 'make sure there is a selected item to modify  
                EditIngeInRecipe.ShowDialog()
                ListView1.SelectedItems(0).SubItems(0).Text = EditIngeInRecipe.cmbIngreName.Text
                ListView1.SelectedItems(0).SubItems(1).Text = EditIngeInRecipe.txtPrepComment.Text
                ListView1.SelectedItems(0).SubItems(2).Text = EditIngeInRecipe.txtIngeWeight.Text
                ListView1.SelectedItems(0).SubItems(3).Text = EditIngeInRecipe.txtIngrAmount.Text
                ListView1.SelectedItems(0).SubItems(4).Text = EditIngeInRecipe.cmbMeasureUnit.Text
            End If
        Else
            MsgBox("Please select Ingredient Item and then choose Edit Ingredient", MsgBoxStyle.Information, "P L E A S E  N O T E !")
        End If
    End Sub

    Private Sub ToolStripButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton7.Click
        AddIngredients.ShowDialog()
        If AddIngredients.Cancel <> True Then
            If AddIngredients.txtIngredientName.Text <> "" Then
                Dim lv As ListViewItem = Form1.ListView6.Items.Add(AddIngredients.txtIngredientName.Text)
                Dim Price As Decimal = AddIngredients.txtPriceItem.Text
                lv.SubItems.Add(Price)
                lv.SubItems.Add(AddIngredients.txtVendorName.Text)
                Dim Measure As Decimal = AddIngredients.txtMeasure.Text
                lv.SubItems.Add(Measure)
                lv.SubItems.Add(AddIngredients.cmbUnit.Text)
            End If
        End If
        Dim MyPathOfAPP As String = (Application.StartupPath.ToString & "\Recipe.rec")
        Dim objStreamWriter As StreamWriter
        Dim strline1, strline2, strline3, strline4, strline5 As String
        objStreamWriter = New StreamWriter(MyPathOfAPP)
        For b = 0 To Form1.ListView6.Items.Count - 1
            strline1 = Form1.ListView6.Items(b).SubItems(0).Text
            strline2 = Form1.ListView6.Items(b).SubItems(1).Text
            strline3 = Form1.ListView6.Items(b).SubItems(2).Text
            strline4 = Form1.ListView6.Items(b).SubItems(3).Text
            strline5 = Form1.ListView6.Items(b).SubItems(4).Text
            objStreamWriter.WriteLine(strline1 & "/" & strline2 & "/" & strline3 & "/" & strline4 & "/" & strline5)
        Next
        objStreamWriter.Close()
        For a = 0 To Form1.ListView6.Items.Count - 1
            cmbMainIngre.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
    End Sub
End Class