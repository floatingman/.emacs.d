﻿Public Class IgredientToRecipe
    Public cancel = False
    Private Sub IgredientToRecipe_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim X As Integer = Form1.MousePosition.X
        Dim y As Integer = Form1.MousePosition.Y
        Me.DesktopLocation = New Point(X, y)
        cmbIngreName.Items.Clear()
        For a = 0 To Form1.ListView6.Items.Count - 1
            cmbIngreName.Items.Add(Form1.ListView6.Items(a).SubItems(0).Text)
        Next
        cmbIngreName.Text = cmbIngreName.Items(0)
        cmbMeasureUnit.Text = cmbMeasureUnit.Items(0)
        txtPrepComment.Text = ""
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim MyBackColor As Color
        MyBackColor = txtPrepComment.BackColor
        If Not IsNumeric(txtIngeWeight.Text) Then
            txtIngeWeight.Focus()
            txtIngeWeight.BackColor = Color.LightPink
            txtIngeWeight.Text = ""
            Exit Sub
        End If
        If Not IsNumeric(txtIngrAmount.Text) Then
            txtIngrAmount.Focus()
            txtIngrAmount.BackColor = Color.LightPink
            txtIngrAmount.Text = ""
            Exit Sub
        End If
        If CDec(txtIngeWeight.Text) = 0 And CDec(txtIngrAmount.Text) = 0 Then
            MsgBox("You can not have both Measure and Weight as 0, please check and correct", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        txtIngeWeight.BackColor = MyBackColor
        txtIngrAmount.BackColor = MyBackColor

        cancel = False
        Me.Close()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        cancel = True
        Me.Close()
    End Sub

    Private Sub txtIngeWeight_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles txtIngeWeight.Validating
        If txtIngeWeight.Text = "" Then
            txtIngeWeight.Text = 0
        End If
        If Not IsNumeric(txtIngeWeight.Text) Then
            txtIngeWeight.Text = 0
        End If
    End Sub

    Private Sub txtIngrAmount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtIngrAmount.TextChanged
        If txtIngrAmount.Text = "" Then
            txtIngrAmount.Text = 0
        End If
        If Not IsNumeric(txtIngrAmount.Text) Then
            txtIngrAmount.Text = 0
        End If
    End Sub
End Class