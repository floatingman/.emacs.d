﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.FILEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddNewIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddNewRecipeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteCurrentRecipeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintCurrentRecipeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveCurrentRecipeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintQoutationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintQuotationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadOldQuotationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddNewCustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditCustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteACustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintListOfCustomersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintInviocesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SETUPPROGRAMFUELToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAYOUTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAYOUT1HORIZONTALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LAYOUT2VERTICALToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer
        Me.SplitContainer8 = New System.Windows.Forms.SplitContainer
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.cmbMainInge_find = New System.Windows.Forms.ComboBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.cmbRecipeBy = New System.Windows.Forms.TextBox
        Me.txtBook = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Button2 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.cmbCategory = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.SplitContainer9 = New System.Windows.Forms.SplitContainer
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.SplitContainer6 = New System.Windows.Forms.SplitContainer
        Me.Label9 = New System.Windows.Forms.Label
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.MenuStrip4 = New System.Windows.Forms.MenuStrip
        Me.ClearItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ShowQuotationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.lblRecipeName = New System.Windows.Forms.Label
        Me.SplitContainer7 = New System.Windows.Forms.SplitContainer
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.MyRichTextBoxEx1 = New Cooking_Calculator.myRichTextBoxEx
        Me.MenuStrip3 = New System.Windows.Forms.MenuStrip
        Me.SaveRecipeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PrintCurrentRecipeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadRecipeFromRTFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SplitContainer4 = New System.Windows.Forms.SplitContainer
        Me.lblDeliveryCost = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.btnCalculateRecipePrice = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtCookTimeFacator = New System.Windows.Forms.TextBox
        Me.txtPrepTimeFactor = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.txtPrepCost = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtDeliveryDistance = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtProfitPercent = New System.Windows.Forms.TextBox
        Me.txtAmountOrdered = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.MyGroupBox1 = New Cooking_Calculator.MyGroupBox
        Me.lblSellingPrice = New System.Windows.Forms.Label
        Me.txtDecorationsPrice = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblCostIngredients = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.SplitContainer5 = New System.Windows.Forms.SplitContainer
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip
        Me.AddIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ListView6 = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddNewIngredientToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EditCurrentIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteCurrentIngredientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog
        Me.SaveFile = New System.Windows.Forms.SaveFileDialog
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.StatusStrip2 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SplitContainer8.Panel1.SuspendLayout()
        Me.SplitContainer8.Panel2.SuspendLayout()
        Me.SplitContainer8.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SplitContainer9.Panel1.SuspendLayout()
        Me.SplitContainer9.Panel2.SuspendLayout()
        Me.SplitContainer9.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.SplitContainer6.Panel1.SuspendLayout()
        Me.SplitContainer6.Panel2.SuspendLayout()
        Me.SplitContainer6.SuspendLayout()
        Me.MenuStrip4.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SplitContainer7.Panel1.SuspendLayout()
        Me.SplitContainer7.Panel2.SuspendLayout()
        Me.SplitContainer7.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.MenuStrip3.SuspendLayout()
        Me.SplitContainer4.Panel1.SuspendLayout()
        Me.SplitContainer4.Panel2.SuspendLayout()
        Me.SplitContainer4.SuspendLayout()
        Me.MyGroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel1.SuspendLayout()
        Me.SplitContainer5.Panel2.SuspendLayout()
        Me.SplitContainer5.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EXITToolStripMenuItem, Me.ToolStripMenuItem1, Me.FILEToolStripMenuItem, Me.PrintQoutationToolStripMenuItem, Me.CustomersToolStripMenuItem, Me.SETUPPROGRAMFUELToolStripMenuItem, Me.LAYOUTToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.MenuStrip1.Size = New System.Drawing.Size(1264, 40)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EXITToolStripMenuItem.Image = CType(resources.GetObject("EXITToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(94, 36)
        Me.EXITToolStripMenuItem.Text = "Exit"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem1.Image = CType(resources.GetObject("ToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(193, 36)
        Me.ToolStripMenuItem1.Text = "Search Recipe"
        '
        'FILEToolStripMenuItem
        '
        Me.FILEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewIngredientToolStripMenuItem, Me.AddNewRecipeToolStripMenuItem, Me.DeleteCurrentRecipeToolStripMenuItem, Me.PrintCurrentRecipeToolStripMenuItem, Me.SaveCurrentRecipeToolStripMenuItem})
        Me.FILEToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FILEToolStripMenuItem.Image = CType(resources.GetObject("FILEToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FILEToolStripMenuItem.Name = "FILEToolStripMenuItem"
        Me.FILEToolStripMenuItem.Size = New System.Drawing.Size(194, 36)
        Me.FILEToolStripMenuItem.Text = "Recipe Details"
        '
        'AddNewIngredientToolStripMenuItem
        '
        Me.AddNewIngredientToolStripMenuItem.Image = CType(resources.GetObject("AddNewIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewIngredientToolStripMenuItem.Name = "AddNewIngredientToolStripMenuItem"
        Me.AddNewIngredientToolStripMenuItem.Size = New System.Drawing.Size(296, 34)
        Me.AddNewIngredientToolStripMenuItem.Text = "Edit current Recipe"
        '
        'AddNewRecipeToolStripMenuItem
        '
        Me.AddNewRecipeToolStripMenuItem.Image = CType(resources.GetObject("AddNewRecipeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewRecipeToolStripMenuItem.Name = "AddNewRecipeToolStripMenuItem"
        Me.AddNewRecipeToolStripMenuItem.Size = New System.Drawing.Size(296, 34)
        Me.AddNewRecipeToolStripMenuItem.Text = "Add New Recipe"
        '
        'DeleteCurrentRecipeToolStripMenuItem
        '
        Me.DeleteCurrentRecipeToolStripMenuItem.Image = CType(resources.GetObject("DeleteCurrentRecipeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteCurrentRecipeToolStripMenuItem.Name = "DeleteCurrentRecipeToolStripMenuItem"
        Me.DeleteCurrentRecipeToolStripMenuItem.Size = New System.Drawing.Size(296, 34)
        Me.DeleteCurrentRecipeToolStripMenuItem.Text = "Delete current Recipe"
        '
        'PrintCurrentRecipeToolStripMenuItem
        '
        Me.PrintCurrentRecipeToolStripMenuItem.Image = CType(resources.GetObject("PrintCurrentRecipeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintCurrentRecipeToolStripMenuItem.Name = "PrintCurrentRecipeToolStripMenuItem"
        Me.PrintCurrentRecipeToolStripMenuItem.Size = New System.Drawing.Size(296, 34)
        Me.PrintCurrentRecipeToolStripMenuItem.Text = "Print current Recipe"
        '
        'SaveCurrentRecipeToolStripMenuItem
        '
        Me.SaveCurrentRecipeToolStripMenuItem.Image = CType(resources.GetObject("SaveCurrentRecipeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveCurrentRecipeToolStripMenuItem.Name = "SaveCurrentRecipeToolStripMenuItem"
        Me.SaveCurrentRecipeToolStripMenuItem.Size = New System.Drawing.Size(296, 34)
        Me.SaveCurrentRecipeToolStripMenuItem.Text = "Save Recipe as RTF"
        '
        'PrintQoutationToolStripMenuItem
        '
        Me.PrintQoutationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintQuotationsToolStripMenuItem, Me.LoadOldQuotationsToolStripMenuItem})
        Me.PrintQoutationToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrintQoutationToolStripMenuItem.Image = CType(resources.GetObject("PrintQoutationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintQoutationToolStripMenuItem.Name = "PrintQoutationToolStripMenuItem"
        Me.PrintQoutationToolStripMenuItem.Size = New System.Drawing.Size(173, 36)
        Me.PrintQoutationToolStripMenuItem.Text = " Quotations"
        '
        'PrintQuotationsToolStripMenuItem
        '
        Me.PrintQuotationsToolStripMenuItem.Enabled = False
        Me.PrintQuotationsToolStripMenuItem.Image = CType(resources.GetObject("PrintQuotationsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintQuotationsToolStripMenuItem.Name = "PrintQuotationsToolStripMenuItem"
        Me.PrintQuotationsToolStripMenuItem.Size = New System.Drawing.Size(288, 34)
        Me.PrintQuotationsToolStripMenuItem.Text = "Print Quotations"
        '
        'LoadOldQuotationsToolStripMenuItem
        '
        Me.LoadOldQuotationsToolStripMenuItem.Image = CType(resources.GetObject("LoadOldQuotationsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoadOldQuotationsToolStripMenuItem.Name = "LoadOldQuotationsToolStripMenuItem"
        Me.LoadOldQuotationsToolStripMenuItem.Size = New System.Drawing.Size(288, 34)
        Me.LoadOldQuotationsToolStripMenuItem.Text = "Load old Quotations"
        '
        'CustomersToolStripMenuItem
        '
        Me.CustomersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewCustomerToolStripMenuItem, Me.EditCustomerToolStripMenuItem, Me.DeleteACustomerToolStripMenuItem, Me.PrintListOfCustomersToolStripMenuItem, Me.PrintInviocesToolStripMenuItem})
        Me.CustomersToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.CustomersToolStripMenuItem.Image = CType(resources.GetObject("CustomersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CustomersToolStripMenuItem.Name = "CustomersToolStripMenuItem"
        Me.CustomersToolStripMenuItem.Size = New System.Drawing.Size(160, 36)
        Me.CustomersToolStripMenuItem.Text = "Customers"
        '
        'AddNewCustomerToolStripMenuItem
        '
        Me.AddNewCustomerToolStripMenuItem.Image = CType(resources.GetObject("AddNewCustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddNewCustomerToolStripMenuItem.Name = "AddNewCustomerToolStripMenuItem"
        Me.AddNewCustomerToolStripMenuItem.Size = New System.Drawing.Size(310, 34)
        Me.AddNewCustomerToolStripMenuItem.Text = "Add New Customer"
        '
        'EditCustomerToolStripMenuItem
        '
        Me.EditCustomerToolStripMenuItem.Image = CType(resources.GetObject("EditCustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditCustomerToolStripMenuItem.Name = "EditCustomerToolStripMenuItem"
        Me.EditCustomerToolStripMenuItem.Size = New System.Drawing.Size(310, 34)
        Me.EditCustomerToolStripMenuItem.Text = "Edit Customer"
        '
        'DeleteACustomerToolStripMenuItem
        '
        Me.DeleteACustomerToolStripMenuItem.Image = CType(resources.GetObject("DeleteACustomerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteACustomerToolStripMenuItem.Name = "DeleteACustomerToolStripMenuItem"
        Me.DeleteACustomerToolStripMenuItem.Size = New System.Drawing.Size(310, 34)
        Me.DeleteACustomerToolStripMenuItem.Text = "Delete a Customer"
        '
        'PrintListOfCustomersToolStripMenuItem
        '
        Me.PrintListOfCustomersToolStripMenuItem.Image = CType(resources.GetObject("PrintListOfCustomersToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintListOfCustomersToolStripMenuItem.Name = "PrintListOfCustomersToolStripMenuItem"
        Me.PrintListOfCustomersToolStripMenuItem.Size = New System.Drawing.Size(310, 34)
        Me.PrintListOfCustomersToolStripMenuItem.Text = "Print List of Customers"
        '
        'PrintInviocesToolStripMenuItem
        '
        Me.PrintInviocesToolStripMenuItem.Image = CType(resources.GetObject("PrintInviocesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PrintInviocesToolStripMenuItem.Name = "PrintInviocesToolStripMenuItem"
        Me.PrintInviocesToolStripMenuItem.Size = New System.Drawing.Size(310, 34)
        Me.PrintInviocesToolStripMenuItem.Text = "Print Invioces"
        '
        'SETUPPROGRAMFUELToolStripMenuItem
        '
        Me.SETUPPROGRAMFUELToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.SETUPPROGRAMFUELToolStripMenuItem.Image = CType(resources.GetObject("SETUPPROGRAMFUELToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SETUPPROGRAMFUELToolStripMenuItem.Name = "SETUPPROGRAMFUELToolStripMenuItem"
        Me.SETUPPROGRAMFUELToolStripMenuItem.Size = New System.Drawing.Size(263, 36)
        Me.SETUPPROGRAMFUELToolStripMenuItem.Text = "Setup Banking / Fuel"
        '
        'LAYOUTToolStripMenuItem
        '
        Me.LAYOUTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LAYOUT1HORIZONTALToolStripMenuItem, Me.LAYOUT2VERTICALToolStripMenuItem})
        Me.LAYOUTToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LAYOUTToolStripMenuItem.Image = CType(resources.GetObject("LAYOUTToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LAYOUTToolStripMenuItem.Name = "LAYOUTToolStripMenuItem"
        Me.LAYOUTToolStripMenuItem.Size = New System.Drawing.Size(124, 36)
        Me.LAYOUTToolStripMenuItem.Text = "Layout"
        '
        'LAYOUT1HORIZONTALToolStripMenuItem
        '
        Me.LAYOUT1HORIZONTALToolStripMenuItem.Image = CType(resources.GetObject("LAYOUT1HORIZONTALToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LAYOUT1HORIZONTALToolStripMenuItem.Name = "LAYOUT1HORIZONTALToolStripMenuItem"
        Me.LAYOUT1HORIZONTALToolStripMenuItem.Size = New System.Drawing.Size(343, 34)
        Me.LAYOUT1HORIZONTALToolStripMenuItem.Text = "LAYOUT 1 - HORIZONTAL"
        '
        'LAYOUT2VERTICALToolStripMenuItem
        '
        Me.LAYOUT2VERTICALToolStripMenuItem.Image = CType(resources.GetObject("LAYOUT2VERTICALToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LAYOUT2VERTICALToolStripMenuItem.Name = "LAYOUT2VERTICALToolStripMenuItem"
        Me.LAYOUT2VERTICALToolStripMenuItem.Size = New System.Drawing.Size(343, 34)
        Me.LAYOUT2VERTICALToolStripMenuItem.Text = "LAYOUT 2 - VERTICAL"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 682)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1264, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 40)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.SplitContainer8)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1264, 642)
        Me.SplitContainer1.SplitterDistance = 234
        Me.SplitContainer1.TabIndex = 0
        '
        'SplitContainer8
        '
        Me.SplitContainer8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer8.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer8.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer8.Name = "SplitContainer8"
        Me.SplitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer8.Panel1
        '
        Me.SplitContainer8.Panel1.Controls.Add(Me.Panel4)
        '
        'SplitContainer8.Panel2
        '
        Me.SplitContainer8.Panel2.Controls.Add(Me.SplitContainer9)
        Me.SplitContainer8.Size = New System.Drawing.Size(234, 642)
        Me.SplitContainer8.SplitterDistance = 281
        Me.SplitContainer8.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.cmbMainInge_find)
        Me.Panel4.Controls.Add(Me.Label17)
        Me.Panel4.Controls.Add(Me.cmbRecipeBy)
        Me.Panel4.Controls.Add(Me.txtBook)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Button2)
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Controls.Add(Me.Button1)
        Me.Panel4.Controls.Add(Me.cmbCategory)
        Me.Panel4.Controls.Add(Me.Label14)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(230, 277)
        Me.Panel4.TabIndex = 0
        '
        'cmbMainInge_find
        '
        Me.cmbMainInge_find.FormattingEnabled = True
        Me.cmbMainInge_find.Location = New System.Drawing.Point(9, 177)
        Me.cmbMainInge_find.Name = "cmbMainInge_find"
        Me.cmbMainInge_find.Size = New System.Drawing.Size(208, 23)
        Me.cmbMainInge_find.TabIndex = 19
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(55, 158)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(108, 15)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Main Ingredient"
        '
        'cmbRecipeBy
        '
        Me.cmbRecipeBy.Location = New System.Drawing.Point(9, 130)
        Me.cmbRecipeBy.Name = "cmbRecipeBy"
        Me.cmbRecipeBy.Size = New System.Drawing.Size(208, 21)
        Me.cmbRecipeBy.TabIndex = 17
        '
        'txtBook
        '
        Me.txtBook.Location = New System.Drawing.Point(6, 73)
        Me.txtBook.Name = "txtBook"
        Me.txtBook.Size = New System.Drawing.Size(211, 21)
        Me.txtBook.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(60, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 15)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Recipe Book"
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(0, 240)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(226, 33)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "Close Search"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(1, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 18)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Recipe Created by:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(63, 206)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(110, 28)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Click to Select"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cmbCategory
        '
        Me.cmbCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbCategory.FormattingEnabled = True
        Me.cmbCategory.Items.AddRange(New Object() {"**ALL**", "Appetizers", "Barbeque & Grilling", "Beef Dishes", "Beverages", "Biscuits & Scones", "Bread Machine", "Breads", "Breakfast", "Cakes", "Candies", "Casseroles", "Chili", "Condiments", "Cookies", "Dairy", "Desserts", "Diabetic", "Dinner", "Dips", "Dressings", "Eggs", "Fat-Free", "Fillings & Frostings", "Fruits", "Grains", "Graves", "Grill", "Gumbo", "Herbs", "Ice Cream", "Jams", "Low Fat", "Main Dish", "Marinades", "Meats", "Microwave", "Mixes", "Muffins", "Noodles", "Nuts", "Pancakes", "Party", "Pasta", "Pastry", "Pies", "Pizza", "Port", "Poultry", "Puddings", "Quick Breads", "Relishes", "Rice", "Salads", "Salsas", "Sandwiches", "Sauces", "Sausages", "Seafoods", "Side Dishes", "Snacks", "Soups", "Spaghetti", "Spices", "Spreads", "Stews", "Stir-Fry", "Vegetable Dishes", "Vegetables"})
        Me.cmbCategory.Location = New System.Drawing.Point(8, 18)
        Me.cmbCategory.Name = "cmbCategory"
        Me.cmbCategory.Size = New System.Drawing.Size(214, 23)
        Me.cmbCategory.Sorted = True
        Me.cmbCategory.TabIndex = 10
        '
        'Label14
        '
        Me.Label14.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(0, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(226, 21)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "Select Type of Recipe"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer9
        '
        Me.SplitContainer9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer9.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer9.IsSplitterFixed = True
        Me.SplitContainer9.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer9.Name = "SplitContainer9"
        Me.SplitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer9.Panel1
        '
        Me.SplitContainer9.Panel1.Controls.Add(Me.Panel5)
        '
        'SplitContainer9.Panel2
        '
        Me.SplitContainer9.Panel2.Controls.Add(Me.SplitContainer6)
        Me.SplitContainer9.Panel2.Controls.Add(Me.ListBox1)
        Me.SplitContainer9.Size = New System.Drawing.Size(230, 353)
        Me.SplitContainer9.SplitterDistance = 37
        Me.SplitContainer9.TabIndex = 4
        '
        'Panel5
        '
        Me.Panel5.AutoSize = True
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(0, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(230, 37)
        Me.Panel5.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(0, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(226, 33)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "PLEASE SELECT THE RECIPE"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer6
        '
        Me.SplitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer6.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.SplitContainer6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SplitContainer6.IsSplitterFixed = True
        Me.SplitContainer6.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer6.Name = "SplitContainer6"
        Me.SplitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer6.Panel1
        '
        Me.SplitContainer6.Panel1.Controls.Add(Me.Label9)
        '
        'SplitContainer6.Panel2
        '
        Me.SplitContainer6.Panel2.Controls.Add(Me.CheckedListBox1)
        Me.SplitContainer6.Panel2.Controls.Add(Me.MenuStrip4)
        Me.SplitContainer6.Size = New System.Drawing.Size(230, 288)
        Me.SplitContainer6.SplitterDistance = 48
        Me.SplitContainer6.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Location = New System.Drawing.Point(0, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(228, 46)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "POSSIBLE RECIPES FOR CUSTOMER  QUOTATION"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.CheckOnClick = True
        Me.CheckedListBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckedListBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(0, 28)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.ScrollAlwaysVisible = True
        Me.CheckedListBox1.Size = New System.Drawing.Size(228, 191)
        Me.CheckedListBox1.TabIndex = 0
        Me.CheckedListBox1.TabStop = False
        Me.CheckedListBox1.ThreeDCheckBoxes = True
        Me.ToolTip1.SetToolTip(Me.CheckedListBox1, "Check the Items you want to add to your Quotation.  " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Leave unchecked, if you wan" & _
                "t to leave out of Quotation")
        '
        'MenuStrip4
        '
        Me.MenuStrip4.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip4.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearItemsToolStripMenuItem, Me.ShowQuotationToolStripMenuItem})
        Me.MenuStrip4.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip4.Name = "MenuStrip4"
        Me.MenuStrip4.Size = New System.Drawing.Size(228, 28)
        Me.MenuStrip4.TabIndex = 1
        Me.MenuStrip4.Text = "Show Quotation"
        '
        'ClearItemsToolStripMenuItem
        '
        Me.ClearItemsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearItemsToolStripMenuItem.Image = CType(resources.GetObject("ClearItemsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ClearItemsToolStripMenuItem.Name = "ClearItemsToolStripMenuItem"
        Me.ClearItemsToolStripMenuItem.Size = New System.Drawing.Size(67, 24)
        Me.ClearItemsToolStripMenuItem.Text = "Clear"
        '
        'ShowQuotationToolStripMenuItem
        '
        Me.ShowQuotationToolStripMenuItem.Enabled = False
        Me.ShowQuotationToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ShowQuotationToolStripMenuItem.Image = CType(resources.GetObject("ShowQuotationToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ShowQuotationToolStripMenuItem.Name = "ShowQuotationToolStripMenuItem"
        Me.ShowQuotationToolStripMenuItem.Size = New System.Drawing.Size(129, 24)
        Me.ShowQuotationToolStripMenuItem.Text = "Show Quotation"
        '
        'ListBox1
        '
        Me.ListBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListBox1.ContextMenuStrip = Me.ContextMenuStrip1
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.HelpProvider1.SetHelpKeyword(Me.ListBox1, "Click on a recipe in the list to display the details of the recipe")
        Me.HelpProvider1.SetHelpString(Me.ListBox1, "Click on a recipe in the list to display the details of the recipe")
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(0, 0)
        Me.ListBox1.Name = "ListBox1"
        Me.HelpProvider1.SetShowHelp(Me.ListBox1, True)
        Me.ListBox1.Size = New System.Drawing.Size(230, 4)
        Me.ListBox1.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.ListBox1, "Click on the recipe you want to display" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "the details of.  To ADD a new Recipe, or" & _
                " " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "EDIT , DELETE a current recipe, click on" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Recipe Details." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpProvider1.SetHelpNavigator(Me.ContextMenuStrip1, System.Windows.Forms.HelpNavigator.KeywordIndex)
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4, Me.ToolStripMenuItem5})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.HelpProvider1.SetShowHelp(Me.ContextMenuStrip1, True)
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(236, 156)
        Me.ContextMenuStrip1.Text = "Recipe MENU's"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(235, 38)
        Me.ToolStripMenuItem2.Text = "Add New Recipe"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Image = CType(resources.GetObject("ToolStripMenuItem3.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(235, 38)
        Me.ToolStripMenuItem3.Text = "Remove Current Recipe"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Image = CType(resources.GetObject("ToolStripMenuItem4.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(235, 38)
        Me.ToolStripMenuItem4.Text = "Edit Current Recipe"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Image = CType(resources.GetObject("ToolStripMenuItem5.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(235, 38)
        Me.ToolStripMenuItem5.Text = "Print Current Recipe"
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.SplitContainer3)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.SplitContainer4)
        Me.SplitContainer2.Size = New System.Drawing.Size(1026, 642)
        Me.SplitContainer2.SplitterDistance = 398
        Me.SplitContainer2.TabIndex = 0
        '
        'SplitContainer3
        '
        Me.SplitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.DataGridView1)
        Me.SplitContainer3.Panel1.Controls.Add(Me.Panel2)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.SplitContainer7)
        Me.SplitContainer3.Size = New System.Drawing.Size(1026, 398)
        Me.SplitContainer3.SplitterDistance = 571
        Me.SplitContainer3.TabIndex = 0
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.Location = New System.Drawing.Point(0, 43)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(567, 351)
        Me.DataGridView1.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(567, 43)
        Me.Panel2.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.lblRecipeName)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(563, 39)
        Me.Panel3.TabIndex = 0
        '
        'lblRecipeName
        '
        Me.lblRecipeName.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblRecipeName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRecipeName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblRecipeName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecipeName.Location = New System.Drawing.Point(0, 0)
        Me.lblRecipeName.Name = "lblRecipeName"
        Me.lblRecipeName.Size = New System.Drawing.Size(559, 35)
        Me.lblRecipeName.TabIndex = 0
        Me.lblRecipeName.Text = "Recipe "
        Me.lblRecipeName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'SplitContainer7
        '
        Me.SplitContainer7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer7.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer7.IsSplitterFixed = True
        Me.SplitContainer7.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer7.Name = "SplitContainer7"
        Me.SplitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer7.Panel1
        '
        Me.SplitContainer7.Panel1.Controls.Add(Me.Panel6)
        '
        'SplitContainer7.Panel2
        '
        Me.SplitContainer7.Panel2.Controls.Add(Me.MyRichTextBoxEx1)
        Me.SplitContainer7.Panel2.Controls.Add(Me.MenuStrip3)
        Me.SplitContainer7.Size = New System.Drawing.Size(451, 398)
        Me.SplitContainer7.SplitterDistance = 38
        Me.SplitContainer7.TabIndex = 1
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(0, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(447, 34)
        Me.Panel6.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(443, 30)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "RECIPE STEPS"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MyRichTextBoxEx1
        '
        Me.MyRichTextBoxEx1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MyRichTextBoxEx1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyRichTextBoxEx1.Location = New System.Drawing.Point(0, 32)
        Me.MyRichTextBoxEx1.Name = "MyRichTextBoxEx1"
        Me.MyRichTextBoxEx1.ShortcutsEnabled = False
        Me.HelpProvider1.SetShowHelp(Me.MyRichTextBoxEx1, True)
        Me.MyRichTextBoxEx1.Size = New System.Drawing.Size(447, 320)
        Me.MyRichTextBoxEx1.TabIndex = 2
        Me.MyRichTextBoxEx1.Text = ""
        '
        'MenuStrip3
        '
        Me.MenuStrip3.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip3.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaveRecipeToolStripMenuItem, Me.PrintCurrentRecipeToolStripMenuItem1, Me.LoadRecipeFromRTFToolStripMenuItem})
        Me.MenuStrip3.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip3.Name = "MenuStrip3"
        Me.MenuStrip3.Size = New System.Drawing.Size(447, 32)
        Me.MenuStrip3.TabIndex = 1
        Me.MenuStrip3.Text = "MenuStrip3"
        '
        'SaveRecipeToolStripMenuItem
        '
        Me.SaveRecipeToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaveRecipeToolStripMenuItem.Image = CType(resources.GetObject("SaveRecipeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveRecipeToolStripMenuItem.Name = "SaveRecipeToolStripMenuItem"
        Me.SaveRecipeToolStripMenuItem.Size = New System.Drawing.Size(111, 28)
        Me.SaveRecipeToolStripMenuItem.Text = "Save Recipe"
        '
        'PrintCurrentRecipeToolStripMenuItem1
        '
        Me.PrintCurrentRecipeToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrintCurrentRecipeToolStripMenuItem1.Image = CType(resources.GetObject("PrintCurrentRecipeToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.PrintCurrentRecipeToolStripMenuItem1.Name = "PrintCurrentRecipeToolStripMenuItem1"
        Me.PrintCurrentRecipeToolStripMenuItem1.Size = New System.Drawing.Size(157, 28)
        Me.PrintCurrentRecipeToolStripMenuItem1.Text = "Print Current Recipe"
        '
        'LoadRecipeFromRTFToolStripMenuItem
        '
        Me.LoadRecipeFromRTFToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoadRecipeFromRTFToolStripMenuItem.Image = CType(resources.GetObject("LoadRecipeFromRTFToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LoadRecipeFromRTFToolStripMenuItem.Name = "LoadRecipeFromRTFToolStripMenuItem"
        Me.LoadRecipeFromRTFToolStripMenuItem.Size = New System.Drawing.Size(165, 28)
        Me.LoadRecipeFromRTFToolStripMenuItem.Text = "Load Recipe from RTF"
        '
        'SplitContainer4
        '
        Me.SplitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer4.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer4.Name = "SplitContainer4"
        '
        'SplitContainer4.Panel1
        '
        Me.SplitContainer4.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.SplitContainer4.Panel1.Controls.Add(Me.lblDeliveryCost)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label18)
        Me.SplitContainer4.Panel1.Controls.Add(Me.btnCalculateRecipePrice)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label16)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtCookTimeFacator)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtPrepTimeFactor)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label15)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label13)
        Me.SplitContainer4.Panel1.Controls.Add(Me.CheckBox1)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtPrepCost)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label12)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtDeliveryDistance)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label11)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtProfitPercent)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtAmountOrdered)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label8)
        Me.SplitContainer4.Panel1.Controls.Add(Me.MyGroupBox1)
        Me.SplitContainer4.Panel1.Controls.Add(Me.txtDecorationsPrice)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label10)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label7)
        Me.SplitContainer4.Panel1.Controls.Add(Me.lblCostIngredients)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label6)
        Me.SplitContainer4.Panel1.Controls.Add(Me.Label5)
        '
        'SplitContainer4.Panel2
        '
        Me.SplitContainer4.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer4.Size = New System.Drawing.Size(1026, 240)
        Me.SplitContainer4.SplitterDistance = 570
        Me.SplitContainer4.TabIndex = 1
        '
        'lblDeliveryCost
        '
        Me.lblDeliveryCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDeliveryCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDeliveryCost.Location = New System.Drawing.Point(101, 153)
        Me.lblDeliveryCost.Name = "lblDeliveryCost"
        Me.lblDeliveryCost.Size = New System.Drawing.Size(74, 23)
        Me.lblDeliveryCost.TabIndex = 28
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(18, 154)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(77, 15)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "Delivery Cost"
        '
        'btnCalculateRecipePrice
        '
        Me.btnCalculateRecipePrice.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCalculateRecipePrice.BackgroundImage = CType(resources.GetObject("btnCalculateRecipePrice.BackgroundImage"), System.Drawing.Image)
        Me.btnCalculateRecipePrice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnCalculateRecipePrice.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCalculateRecipePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpProvider1.SetHelpString(Me.btnCalculateRecipePrice, "Click the button to calculate the final cost of the current selected recipes")
        Me.btnCalculateRecipePrice.Location = New System.Drawing.Point(483, 30)
        Me.btnCalculateRecipePrice.Name = "btnCalculateRecipePrice"
        Me.HelpProvider1.SetShowHelp(Me.btnCalculateRecipePrice, True)
        Me.btnCalculateRecipePrice.Size = New System.Drawing.Size(80, 71)
        Me.btnCalculateRecipePrice.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.btnCalculateRecipePrice, "Click to Calcultate the Price of a Recipe")
        Me.btnCalculateRecipePrice.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(483, 94)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(80, 46)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "Click to Calc"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtCookTimeFacator
        '
        Me.txtCookTimeFacator.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCookTimeFacator.Location = New System.Drawing.Point(363, 63)
        Me.txtCookTimeFacator.Name = "txtCookTimeFacator"
        Me.txtCookTimeFacator.Size = New System.Drawing.Size(35, 21)
        Me.txtCookTimeFacator.TabIndex = 25
        Me.txtCookTimeFacator.Text = "0.08"
        '
        'txtPrepTimeFactor
        '
        Me.txtPrepTimeFactor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrepTimeFactor.Location = New System.Drawing.Point(363, 36)
        Me.txtPrepTimeFactor.Name = "txtPrepTimeFactor"
        Me.txtPrepTimeFactor.Size = New System.Drawing.Size(35, 21)
        Me.txtPrepTimeFactor.TabIndex = 24
        Me.txtPrepTimeFactor.Text = "0.75"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(266, 66)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(93, 15)
        Me.Label15.TabIndex = 23
        Me.Label15.Text = "Cook Time Cost"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(266, 37)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(91, 15)
        Me.Label13.TabIndex = 22
        Me.Label13.Text = "Prep Time Cost"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CheckBox1.Enabled = False
        Me.CheckBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(21, 181)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(287, 28)
        Me.CheckBox1.TabIndex = 21
        Me.CheckBox1.Text = "Check to Add Customer List"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'txtPrepCost
        '
        Me.txtPrepCost.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtPrepCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrepCost.Location = New System.Drawing.Point(363, 88)
        Me.txtPrepCost.Name = "txtPrepCost"
        Me.txtPrepCost.ReadOnly = True
        Me.txtPrepCost.Size = New System.Drawing.Size(52, 21)
        Me.txtPrepCost.TabIndex = 20
        Me.txtPrepCost.Text = "0"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(266, 91)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(95, 15)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Total Time Cost:"
        '
        'txtDeliveryDistance
        '
        Me.txtDeliveryDistance.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDeliveryDistance.Location = New System.Drawing.Point(150, 122)
        Me.txtDeliveryDistance.Name = "txtDeliveryDistance"
        Me.txtDeliveryDistance.Size = New System.Drawing.Size(47, 21)
        Me.txtDeliveryDistance.TabIndex = 18
        Me.txtDeliveryDistance.Text = "5"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(18, 125)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(126, 15)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Delivery Distance Km:"
        '
        'txtProfitPercent
        '
        Me.txtProfitPercent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProfitPercent.Location = New System.Drawing.Point(68, 63)
        Me.txtProfitPercent.Name = "txtProfitPercent"
        Me.txtProfitPercent.Size = New System.Drawing.Size(30, 21)
        Me.txtProfitPercent.TabIndex = 16
        Me.txtProfitPercent.Text = "10"
        '
        'txtAmountOrdered
        '
        Me.txtAmountOrdered.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmountOrdered.Location = New System.Drawing.Point(223, 63)
        Me.txtAmountOrdered.Name = "txtAmountOrdered"
        Me.txtAmountOrdered.Size = New System.Drawing.Size(37, 21)
        Me.txtAmountOrdered.TabIndex = 14
        Me.txtAmountOrdered.Text = "1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(117, 66)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 15)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Amount Ordered:"
        '
        'MyGroupBox1
        '
        Me.MyGroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MyGroupBox1.BorderColor = System.Drawing.Color.Red
        Me.MyGroupBox1.Controls.Add(Me.lblSellingPrice)
        Me.MyGroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MyGroupBox1.ForeColor = System.Drawing.Color.Red
        Me.MyGroupBox1.Location = New System.Drawing.Point(399, 157)
        Me.MyGroupBox1.Name = "MyGroupBox1"
        Me.MyGroupBox1.Size = New System.Drawing.Size(164, 52)
        Me.MyGroupBox1.TabIndex = 12
        Me.MyGroupBox1.TabStop = False
        Me.MyGroupBox1.Text = " [  SELLING PRICE  ]"
        '
        'lblSellingPrice
        '
        Me.lblSellingPrice.BackColor = System.Drawing.Color.White
        Me.lblSellingPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSellingPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSellingPrice.Location = New System.Drawing.Point(20, 18)
        Me.lblSellingPrice.Name = "lblSellingPrice"
        Me.lblSellingPrice.Size = New System.Drawing.Size(119, 31)
        Me.lblSellingPrice.TabIndex = 6
        Me.lblSellingPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtDecorationsPrice
        '
        Me.txtDecorationsPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDecorationsPrice.Location = New System.Drawing.Point(173, 91)
        Me.txtDecorationsPrice.Name = "txtDecorationsPrice"
        Me.txtDecorationsPrice.Size = New System.Drawing.Size(77, 21)
        Me.txtDecorationsPrice.TabIndex = 10
        Me.txtDecorationsPrice.Text = "0"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(15, 94)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(164, 15)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Decorations  and Extras  :  R "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(15, 66)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 15)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Profit  % :"
        '
        'lblCostIngredients
        '
        Me.lblCostIngredients.BackColor = System.Drawing.Color.White
        Me.lblCostIngredients.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCostIngredients.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostIngredients.Location = New System.Drawing.Point(161, 33)
        Me.lblCostIngredients.Name = "lblCostIngredients"
        Me.lblCostIngredients.Size = New System.Drawing.Size(77, 23)
        Me.lblCostIngredients.TabIndex = 2
        Me.lblCostIngredients.Text = "0"
        Me.lblCostIngredients.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(15, 35)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(143, 15)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Cost Price -> Ingredients:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(0, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(566, 27)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Price Detail on Recipe:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.SplitContainer5)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(448, 236)
        Me.Panel1.TabIndex = 0
        '
        'SplitContainer5
        '
        Me.SplitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.SplitContainer5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer5.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer5.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer5.Name = "SplitContainer5"
        Me.SplitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer5.Panel1
        '
        Me.SplitContainer5.Panel1.Controls.Add(Me.MenuStrip2)
        '
        'SplitContainer5.Panel2
        '
        Me.SplitContainer5.Panel2.Controls.Add(Me.ListView6)
        Me.SplitContainer5.Size = New System.Drawing.Size(444, 232)
        Me.SplitContainer5.SplitterDistance = 40
        Me.SplitContainer5.TabIndex = 0
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip2.ImageScalingSize = New System.Drawing.Size(26, 26)
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddIngredientToolStripMenuItem, Me.EditIngredientToolStripMenuItem, Me.DeleteIngredientToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(440, 36)
        Me.MenuStrip2.TabIndex = 0
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'AddIngredientToolStripMenuItem
        '
        Me.AddIngredientToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddIngredientToolStripMenuItem.Image = CType(resources.GetObject("AddIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddIngredientToolStripMenuItem.Name = "AddIngredientToolStripMenuItem"
        Me.AddIngredientToolStripMenuItem.Size = New System.Drawing.Size(129, 32)
        Me.AddIngredientToolStripMenuItem.Text = "Add Ingredient"
        '
        'EditIngredientToolStripMenuItem
        '
        Me.EditIngredientToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditIngredientToolStripMenuItem.Image = CType(resources.GetObject("EditIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditIngredientToolStripMenuItem.Name = "EditIngredientToolStripMenuItem"
        Me.EditIngredientToolStripMenuItem.Size = New System.Drawing.Size(128, 32)
        Me.EditIngredientToolStripMenuItem.Text = "Edit Ingredient"
        '
        'DeleteIngredientToolStripMenuItem
        '
        Me.DeleteIngredientToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteIngredientToolStripMenuItem.Image = CType(resources.GetObject("DeleteIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteIngredientToolStripMenuItem.Name = "DeleteIngredientToolStripMenuItem"
        Me.DeleteIngredientToolStripMenuItem.Size = New System.Drawing.Size(145, 32)
        Me.DeleteIngredientToolStripMenuItem.Text = "Delete Ingredient"
        '
        'ListView6
        '
        Me.ListView6.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5})
        Me.ListView6.ContextMenuStrip = Me.ContextMenuStrip2
        Me.ListView6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView6.FullRowSelect = True
        Me.ListView6.GridLines = True
        Me.ListView6.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.ListView6.HideSelection = False
        Me.ListView6.Location = New System.Drawing.Point(0, 0)
        Me.ListView6.MultiSelect = False
        Me.ListView6.Name = "ListView6"
        Me.ListView6.Size = New System.Drawing.Size(440, 184)
        Me.ListView6.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.ListView6.TabIndex = 0
        Me.ListView6.UseCompatibleStateImageBehavior = False
        Me.ListView6.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Ingredient Name"
        Me.ColumnHeader1.Width = 147
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Price"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Vendor"
        Me.ColumnHeader3.Width = 137
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Measure"
        Me.ColumnHeader4.Width = 90
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Unit"
        Me.ColumnHeader5.Width = 170
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip2.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddNewIngredientToolStripMenuItem1, Me.EditCurrentIngredientToolStripMenuItem, Me.DeleteCurrentIngredientToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(251, 118)
        '
        'AddNewIngredientToolStripMenuItem1
        '
        Me.AddNewIngredientToolStripMenuItem1.Image = CType(resources.GetObject("AddNewIngredientToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AddNewIngredientToolStripMenuItem1.Name = "AddNewIngredientToolStripMenuItem1"
        Me.AddNewIngredientToolStripMenuItem1.Size = New System.Drawing.Size(250, 38)
        Me.AddNewIngredientToolStripMenuItem1.Text = "Add New Ingredient"
        '
        'EditCurrentIngredientToolStripMenuItem
        '
        Me.EditCurrentIngredientToolStripMenuItem.Image = CType(resources.GetObject("EditCurrentIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditCurrentIngredientToolStripMenuItem.Name = "EditCurrentIngredientToolStripMenuItem"
        Me.EditCurrentIngredientToolStripMenuItem.Size = New System.Drawing.Size(250, 38)
        Me.EditCurrentIngredientToolStripMenuItem.Text = "Edit Current Ingredient"
        '
        'DeleteCurrentIngredientToolStripMenuItem
        '
        Me.DeleteCurrentIngredientToolStripMenuItem.Image = CType(resources.GetObject("DeleteCurrentIngredientToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DeleteCurrentIngredientToolStripMenuItem.Name = "DeleteCurrentIngredientToolStripMenuItem"
        Me.DeleteCurrentIngredientToolStripMenuItem.Size = New System.Drawing.Size(250, 38)
        Me.DeleteCurrentIngredientToolStripMenuItem.Text = "Delete Current Ingredient"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'PrintDocument1
        '
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'StatusStrip2
        '
        Me.StatusStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip2.Location = New System.Drawing.Point(0, 656)
        Me.StatusStrip2.Name = "StatusStrip2"
        Me.StatusStrip2.Size = New System.Drawing.Size(1264, 26)
        Me.StatusStrip2.TabIndex = 2
        Me.StatusStrip2.Text = "StatusStrip2"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(177, 21)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(1264, 704)
        Me.ControlBox = False
        Me.Controls.Add(Me.StatusStrip2)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Enabled = False
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "RECIPE CALCULATOR"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer8.Panel1.ResumeLayout(False)
        Me.SplitContainer8.Panel2.ResumeLayout(False)
        Me.SplitContainer8.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.SplitContainer9.Panel1.ResumeLayout(False)
        Me.SplitContainer9.Panel1.PerformLayout()
        Me.SplitContainer9.Panel2.ResumeLayout(False)
        Me.SplitContainer9.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.SplitContainer6.Panel1.ResumeLayout(False)
        Me.SplitContainer6.Panel2.ResumeLayout(False)
        Me.SplitContainer6.Panel2.PerformLayout()
        Me.SplitContainer6.ResumeLayout(False)
        Me.MenuStrip4.ResumeLayout(False)
        Me.MenuStrip4.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.SplitContainer7.Panel1.ResumeLayout(False)
        Me.SplitContainer7.Panel2.ResumeLayout(False)
        Me.SplitContainer7.Panel2.PerformLayout()
        Me.SplitContainer7.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.MenuStrip3.ResumeLayout(False)
        Me.MenuStrip3.PerformLayout()
        Me.SplitContainer4.Panel1.ResumeLayout(False)
        Me.SplitContainer4.Panel1.PerformLayout()
        Me.SplitContainer4.Panel2.ResumeLayout(False)
        Me.SplitContainer4.ResumeLayout(False)
        Me.MyGroupBox1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel1.ResumeLayout(False)
        Me.SplitContainer5.Panel1.PerformLayout()
        Me.SplitContainer5.Panel2.ResumeLayout(False)
        Me.SplitContainer5.ResumeLayout(False)
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ContextMenuStrip2.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip2.ResumeLayout(False)
        Me.StatusStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FILEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer3 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents AddNewIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView6 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents SplitContainer4 As System.Windows.Forms.SplitContainer
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents AddIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblSellingPrice As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblCostIngredients As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtDecorationsPrice As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents MyGroupBox1 As Cooking_Calculator.MyGroupBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents SplitContainer7 As System.Windows.Forms.SplitContainer
    Friend WithEvents AddNewRecipeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteCurrentRecipeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintCurrentRecipeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer8 As System.Windows.Forms.SplitContainer
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer9 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents cmbCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblRecipeName As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents SplitContainer5 As System.Windows.Forms.SplitContainer
    Friend WithEvents txtBook As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cmbRecipeBy As System.Windows.Forms.TextBox
    Friend WithEvents LAYOUTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAYOUT1HORIZONTALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAYOUT2VERTICALToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents btnCalculateRecipePrice As System.Windows.Forms.Button
    Friend WithEvents txtAmountOrdered As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtProfitPercent As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtDeliveryDistance As System.Windows.Forms.TextBox
    Friend WithEvents txtPrepCost As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents MenuStrip3 As System.Windows.Forms.MenuStrip
    Friend WithEvents SaveRecipeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintCurrentRecipeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents MyRichTextBoxEx1 As Cooking_Calculator.myRichTextBoxEx
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents SaveFile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SaveCurrentRecipeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer6 As System.Windows.Forms.SplitContainer
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents PrintQoutationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents MenuStrip4 As System.Windows.Forms.MenuStrip
    Friend WithEvents ClearItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintQuotationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadOldQuotationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents txtCookTimeFacator As System.Windows.Forms.TextBox
    Friend WithEvents txtPrepTimeFactor As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cmbMainInge_find As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents SETUPPROGRAMFUELToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblDeliveryCost As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents CustomersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddNewCustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditCustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteACustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintListOfCustomersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintInviocesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadRecipeFromRTFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip2 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ShowQuotationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddNewIngredientToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditCurrentIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteCurrentIngredientToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
