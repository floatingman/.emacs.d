#include "world.ipp"
#include <ostream>

// Explicitly instantiate template function:
template void HelloWorld<std::ostream>(std::ostream& os);
